#!/usr/bin/env perl 
use strict;
use warnings;

# change .rate1. -> .rate2.
# change .rate-1. -> .rate1.

my $old=""; #"rate1";
my $new=""; #"rate2";

if(scalar(@ARGV)<2){help();}
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-h"){
	help();
    }elsif($ARGV[$i] eq "-old"){
	$i++; $old=$ARGV[$i];
    }elsif($ARGV[$i] eq "-new"){
	$i++; $new=$ARGV[$i];
    }else{
	print "WARNING, unrecognized option $ARGV[$i]\n";
    }
}
if($old eq "" || $new eq ""){help();}

my @list=`ls -1 *${old}*`;
print scalar(@list), " files to change\n";

my $lo=length($old);
my $ln=length($new);

foreach my $file (@list){
    chomp $file;
    if(!-e $file){print "ERROR, $file does not exist\n"; die;}
    my $lf=length($file); my $p;
    for($p=0; $p<$lf; $p++){
	if(substr($file, $p, $lo) eq $old){last;}
    }
    if($p==$lf){
	print "ERROR, file $file does not contain string ${old}\n"; die;
    }
    my $newfile=substr($file, 0, $p).$new.substr($file, $p+$lo);
    my $command="mv $file $newfile\n";
    print $command;
    `$command`;
}

sub help(){
    print "Program $0\n",
    "Changes all file names in the current directory that contain the string ",
    "<old> into same names containing the string <new>\n",
    "USAGE: $0 -old <old> -new <new>\n";
    die;
}
