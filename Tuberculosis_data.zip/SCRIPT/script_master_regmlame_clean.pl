#!/usr/bin/env perl 
use strict;
use warnings;

# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree STRMEV_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy


my $k=0;
foreach my $file(`ls -1 *.br.*.bestTree`){

    chomp $file;
    my ($model, $msa, $branch)= Get_model($file);
    print "\nk=$k file= $file model= $model msa= $msa\n";
    my $dir=Set_dir($model, $msa);
    if(-e $dir && !-d $dir){
	print "ERROR, $dir is a file using current directory\n";
	die;
    }elsif(!-d $dir){
	print "Creating directory $dir\n";
	`mkdir $dir`;
    }else{
	print "Using existing directory $dir\n";
    }

    my $command="mv  *.br.${branch}.*  $dir\n";

    print $command;
    `$command`;
    $k++;
}

sub Get_model{
    my $file=$_[0];
    my @word=split(/\./,$file);
    if(scalar(@word)!=4){
	print "file $file, ERROR in name",
	" (expected: tree.br.msa_model.bestTree)\n"; 
	die;
    }
    my $branch=$word[2];
    my @w=split(/_/,$branch);
    my $msa=$w[0]; my $ini=1;
    if($w[0] eq "AA" && $w[1] eq "DNA"){
	$msa=$msa."_DNA"; $ini=2;
    }
    my $model=$w[$ini];
    for(my $i=$ini+1; $i<scalar(@w); $i++){
	$model=$model."_".$w[$i];
    }
    return($model, $msa, $branch);
}


sub Set_dir{
    my ($model, $msa)=@_;
    my @word=split(/\./,$model); 
    if(scalar(@word)>1){
	return($word[0]); # .partition
    }else{
	my $dir;
	@word=split(/\./,$msa);
	if($word[0] eq "AAnores"){$dir="AA";}
	else{$dir=$word[0];} # AAsyn DNA DNA noAA

	@word=split(/\+/,$model);
	$dir=$dir."_".$word[0];
	if(scalar(@word)>1){
	    if($word[1] eq "FC"){$word[1]="F";}
	    $dir=$dir."_".$word[1];
	}
	if(scalar(@word)==3){$dir=$dir.$word[2];}
	return($dir);
    }
}

sub Remove_extension{
    my ($name, $l)=@_;
    if($l eq ""){$l=1;}
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}
