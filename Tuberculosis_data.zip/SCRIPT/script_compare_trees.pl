#!/usr/bin/env perl 
use strict;
use warnings;

my $compare_trees="/data/ubastolla/BIN/SSCPE/k2_mat.pl";
my @trees=(
    "AA_JTT_FG_DNA2_GTR_G.bestTree",
    "AA_STMTREV_FG_DNA2_TVM_G.bestTree",
    "AA_JTT_FG_DNA_GTR_G.bestTree",
    "AA_STMTREV_FG_DNA_TVM_G.bestTree",
    #"AA_JTT_F_DNA_GTR.bestTree",
    #"AA_STMTREV_F_DNA_TVM.bestTree",
    "AAsyn_STMTREV_FG.bestTree",
    "AAsyn_JTT_FG.bestTree",
    "AA_STMTREV_FG.bestTree",
    "AA_STMTREV_F.bestTree",
    #"AA_JTT_F.bestTree",
    "DNA_TVM_G.bestTree",
    "DNA_TVM.bestTree",
    #"DNA_GTR_G.bestTree"
    #"DNAnoAA_GTR_G.bestTree"
    );

my $file_tree="";

for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-trees"){
	$i++; $file_tree=$ARGV[$i];
    }else{
	print "WARNING, unknown option $ARGV[$i]\n";
    }
}

my $ntree=scalar(@trees);
if(-e $file_tree){
    print "Reading trees in $file_tree\n";
    my $t;
    for($t=0; $t<$ntree; $t++){$trees[$t]="";}
    open(my $fh, '<', $file_tree);
    $t=0;
    while (my $row = <$fh>){
	chomp $row; $trees[$t]=$row; $t++;
    }
    close $fh;
    $ntree=$t;
}else{
    print "Using pre-defined tree topologies\n";
}

my @score; my @sum_score; my @sum_score_ref; my @num;
for(my $i=0; $i<$ntree; $i++){
    $num[$i]=0;
    for(my $j=0; $j<3; $j++){
	$sum_score[$i][$j]=0;
	$sum_score_ref[$i][$j]=0;
	for(my $k=0; $k<$ntree; $k++){$score[$i][$k][$j]=0;}
    }
}

my $i=-1;
foreach my $tree1(@trees){
    my $name1=Remove_extension($tree1, 1);
    $i++;
    my $k=-1;
    foreach my $tree2(@trees){
	$k++;
	if($tree2 eq $tree1){next;}
	my $name2=Remove_extension($tree2, 1);
	my $table="Diff.$name1.$name2";

	if(!-e $table){
	    my $command=$compare_trees.
		" -rt $tree1 -ct $tree2 -r -n -norm -t $table\n";
	    print $command;
	    `$command`;
	    if(!-e $table){next;}
	}


	print "Reading $table\n";
	open(my $fh, '<', $table);
	while(my $row = <$fh>){
	    chomp $row;
	    my @word=split(/\t/, $row);
	    if($word[0] eq "Trees"){next;}
	    if(scalar(@word)<11){next;}
	    $score[$i][$k][0]=$word[7]; # RF
	    $score[$i][$k][1]=$word[2]; # K1
	    $score[$i][$k][2]=$word[4]; # K2
	    $num[$k]++;
	    for(my $j=0; $j<3; $j++){
		$sum_score[$k][$j]+=$score[$i][$k][$j];
		$sum_score_ref[$i][$j]+=$score[$i][$k][$j];
	    }
	    last;
	}
	close $fh;
    }
}
for(my $j=0; $j<3; $j++){
    my $type;
    if($j==0){$type="RF";}
    elsif($j==1){$type="K1";}
    elsif($j==2){$type="K2";}
    my $output="Results_Trees_${type}.txt";
    open(my $fo, '>', $output);
    print "Writing $output\n";
    print $fo "# tree ave(${type}_ref) ave(${type}_comp) num\n";
    my $imin=-1; my $imin_ref=-1;
    for(my $i=0; $i<$ntree; $i++){
	print $fo Remove_extension($trees[$i], 1);
	if($num[$i]){
	    $sum_score[$i][$j]/=$num[$i];
	    $sum_score_ref[$i][$j]/=$num[$i];
	}
	print $fo sprintf("\t%.4f\t%.4f",
			  $sum_score_ref[$i][$j], $sum_score[$i][$j]);
	print $fo "\t$num[$i]\n";
	if($imin<0 || $sum_score[$i][$j]<$sum_score[$imin][$j]){$imin=$i;}
	if($imin_ref<0 || $sum_score_ref[$i][$j]<$sum_score_ref[$imin_ref][$j])
	{$imin_ref=$i;}
    }
    print $fo "# Central tree (ref): ", Remove_extension($trees[$imin_ref], 1),
    sprintf(" %.4f\n", $sum_score_ref[$imin_ref][$j]);
    print $fo "# Central tree (comp): ", Remove_extension($trees[$imin], 1),
    sprintf(" %.4f\n", $sum_score[$imin][$j]);
   for(my $i=0; $i<$ntree; $i++){
	print $fo "#".Remove_extension($trees[$i], 1);
	for(my $k=0; $k<$ntree; $k++){
	    print $fo sprintf("\t%.4f", $score[$i][$k][$j]);
	}
	print $fo "\n";
    }
    close $fo;
}

sub Remove_extension{
    my ($name, $l)=@_;
    if($l eq ""){$l=1;}
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub help(){
    print 
	"\nProgram $0, author Ugo Bastolla <ubastolla\@cbm.csic.es>\n",
	"It computes all pairwise distances between trees in a list\n",
	"It prints average distances in the table Diff_trees.txt\n",
	"USAGE: $0  ",
	"-tree <list of trees in Newick format>\n",
	"Example: $0 -tree trees.list\n\n";
    die;
}

