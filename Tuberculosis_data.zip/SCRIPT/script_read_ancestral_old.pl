#!/usr/bin/env perl 
use strict;
use warnings;

my $step=1; # set to zero if you have to compute branch lengths
my $raxml="/data/ubastolla/BIN/SSCPE/raxml-ng"; # change as needed
my $analyze_asr= # change as needed
    "/data/ubastolla/TUBERCULOSIS/SOURCE/script_analyze_ASR.pl"; 

my $cluster=0;
my @models=("STMTREV+F+G4","JTT+F+G4", #+F +F
	    "GTR+G4","TVM+G4");
my @modname=("STMTREV_AA","JTT_AA",
	     "GTR_DNA","TVM_DNA");
my @dirs=("AA_nosyn_STMTREV_FG",
	  "JTT_F_G4Amino",
	  "STMTREV_F_G4Amino",
	  "DNA_noAA_GTR",
	  "GTR_G4DNA",
	  "TVM_G4DNA");

#my @ali_br=("all_mut.AA.phy","all_mut.DNA.phy");
my @ali_br=("mut.aa.nosyn.phy","all_mut.DNA.phy");
my @ali_asr=("mut.aa.S315T.phy",
	     "mut.aa.resistant.phy",
	     "mut.aa.nosyn.phy",
	     "mut.dna.syn.phy",
	     "mut.dna.intergenic.phy");
my @name_asr=("S315","R","AA","SYN","IG");
#my @best_mod=(0,0,0,2,2); # for aa ASR, best mod are STMTREV_AA,JTT_AA,
my @best_mod=(1,1,1,3,3);

my $submit="qsubmit.pl -q x86_64 --mem 4";

#raxml-ng --evaluate  --tree --model  --msa
#raxml-ng 

my $n=0;



if($step==0){
# Compute branch lengths, use them for ASR
    print "Compute branch lengths with all models\n";
    foreach my $dir (@dirs){
	chdir($dir);
	my $tree=$dir.".bestTree";
	for(my $m=0; $m<scalar(@models); $m++){
	    my $ali;
	    if($m<2){$ali=$ali_br[0];}
	    else{$ali=$ali_br[1];}
	    my $newali="$dir.br.$modname[$m]";
	    `cp ../$ali $newali`;
	    my $command="$raxml --evaluate --tree $tree --msa $newali".
		" --model $models[$m] --outgroup M_can\n";
	    print $command;
	    if($cluster){
		my $script="tmp$n";
		open(my $fo, '>', $script);
		print $fo $command;
		print $fo "rm -f $newali\n";
		close $fo;
		`chmod u+x $script`;
		`$submit -s $script`;
	    }else{
		`$command`;
		`rm -f $newali`;
	    }
	    $n++;
	} # end model
	my $script="script_clean";
	open(my $fo, '>', $script);
	my $namelik="${dir}.loglik";
	print $fo "grep AIC *.log > $namelik\n";
	print $fo "grep contains *.log >> $namelik\n";
	print $fo "rm -f *.startTree\n";
	print $fo "rm -f *.mlTrees\n";
	print $fo "rm -f *.rba\n";
	print $fo "rm -f tmp*\n";
	print $fo "rm -f *.log\n";
	for(my $m=0; $m<scalar(@models); $m++){
	    my $newali="$dir.br.$modname[$m]";
	    print $fo "rm -f $newali\n";
	    print $fo "mv ${newali}.raxml.bestModel ${newali}.bestModel\n";
	    print $fo "mv ${newali}.raxml.bestTree  ${newali}.bestTree\n";
	    print $fo "mv ${newali}.raxml.bestTreeCollapsed ",
	    "${newali}.bestTreeCollapsed\n";
	}
	close $fo;
	`chmod u+x $script`;
	print "Changing names and removing not needed files\n";
	if($cluster==0){`$script`;}
	chdir("../");
    } # end tree
    
    if($cluster){
	my $sleep=120;
	print "Sleeping $sleep seconds\n";
	sleep $sleep;
    }
}

# Second part: make ASR
print "Infer Ancestral Sequences with computed branches\n"; 
foreach my $dir (@dirs){
    chdir($dir);
    my @alis;
    for(my $i=0; $i<scalar(@ali_asr); $i++){
	my $m=$best_mod[$i];
	my $name="$dir.br.$modname[$m]";
	my $ali="${name}.".Remove_extension($ali_asr[$i]);
	$alis[$i]=$ali;
	if(!-e $ali){`cp ../$ali_asr[$i] $ali`;}
	my $tree=$name.".bestTree";
	my $file=$name.".bestModel";
	open(my $fh, '<', $file);
	my $model = <$fh>;
	close $fh;
	chomp $model;
	my $l;
	for($l=0; $l<length($model); $l++){
	    if(substr($model, $l, 1) eq ","){last;}
	}
	$model=substr($model, 0, $l);
	
	my $command="$raxml --ancestral --tree $tree --msa $ali ".
	    "--model $model --opt-branches off --opt-model off ".
	    "--outgroup M_can\n";
	print $command;
	my $script="tmp$n";
	open(my $fo, '>', $script);
	print $fo $command; 
	close $fo;
	`chmod u+x $script`;
	if($cluster){
	    `$submit -s $script`;
	}else{
	    `$command`;
	}
	$n++;
    } # end ali_asr
    my $script="script_clean2";
    open(my $fo, '>', $script);
    my $namelik="${dir}.ASR.loglik";
    print $fo "grep AIC *.log > $namelik\n";
    print $fo "grep contains *.log >> $namelik\n";
    print $fo "rm -f *.startTree\n";
    print $fo "rm -f *.mlTrees\n";
    print $fo "rm -f *.rba\n";
    print $fo "rm -f tmp*\n";
    print $fo "rm -f *.log\n";
    print $fo "rm -f *.ancestralProbs\n";
    # analyze ASR
    for(my $i=0; $i<scalar(@ali_asr); $i++){
	my $a_i=$alis[$i];
	my $asr_tree=$a_i.".ancestralTree";
	my $asr_seqs=$a_i.".ancestralStates";
	print $fo "mv ${a_i}.raxml.ancestralStates $asr_seqs\n";
	print $fo "mv ${a_i}.raxml.ancestralTree   $asr_tree\n";
	print $fo "$analyze_asr -tree $asr_tree -asr $asr_seqs -seq $a_i\n";
	print $fo "rm -f $a_i\n";
    }
    close $fo;
    `chmod u+x $script`;
    print "Changing names and removing not needed files\n";
    if($cluster==0){`$script`;}
# analyzing asr
    
    chdir("../");
} # end dir


sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}
