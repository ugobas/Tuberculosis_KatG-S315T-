#!/usr/bin/env perl 
use strict;
use warnings;
use Getopt::Long;
use Cwd qw(getcwd);

# Input arguments
my $file_tree="";
my $file_names="";
if(scalar(@ARGV)<2){help();}
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-tree"){
	$i++; $file_tree=$ARGV[$i];
   }elsif($ARGV[$i] eq "-names"){
	$i++; $file_names=$ARGV[$i];
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($file_names eq "" || $file_tree eq ""){help();}


# Read names
my $n=0;
my @append=(); my @names=();
open(my $fh, '<', $file_names) or die 'Could not open $file_names!\n';
while (my $row = <$fh>){
    if(substr($row, 0, 1) eq "#"){next;}
    chomp $row;
    my @word=split(/\s+/, $row);
    $names[$n]=$word[0];
    if(scalar(@word)>1){$append[$n]=$word[1];}
    else{$append[$n]="";}
    $n++;
}
close $fh;
print "$n species names read in $file_names\n";
my $n_species=$n;

# Read/write tree
my $input=$file_tree;
my $new=$input.".new";
open(my $fo, '>', $new);
open($fh, '<', $input) or die 'Could not open $input!\n';
my $row = <$fh>; chomp $row;
my $name; my $open=0; my $l=0; my $cname=0; my $out="";
for(my $i=0; $i<length($row); $i++){
    my $read=0;
    if(substr($row, $i, 1) eq "("){
	$open=1; $cname=0; $name="";
    }elsif(substr($row, $i, 1) eq ","){
	if($open){
	    if($cname){$l=Write_appendix($out, $name);}
	    $open=0;
	}else{
	    $open=1;
	}
	$cname=0; $name="";
    }elsif(substr($row, $i, 1) eq ")"){
	if($cname){$l=Write_appendix($out, $name);}
	$open=1; $cname=0; $name="";
    }elsif(substr($row, $i, 1) eq ":"){
	if($cname){$l=Write_appendix($out, $name);}
	$open=0; $cname=0; $name="";
    }elsif($open){
	$read=1;
    }
    #print substr($row, $i, 1)," open=$open read=$read cname= $cname\n";
    if($read){
	substr($name, $cname, 1)=substr($row, $i, 1); $cname++;
    }else{
	substr($out, $l, 1)=substr($row, $i, 1); $l++;
    }
}
print $fo $out;
close $fh; close $fo;
print "Writing names with appendix in $new\n";

sub Write_appendix{
    my ($out, $name) = @_;
    my $k=-1;
    for(my $i=0; $i<$n_species; $i++){
	if($names[$i] eq $name){$k=$i; last;}
    }
    if($k<0){
	print "ERROR, $name not found in $file_names\n"; die;
    }
    $_[0]=$_[0].$name.$append[$k];
    return(length($_[0]));
}


sub help{
    print "ERROR, -tree and -names must be specified\n";
    print
	"USAGE: $0 \n",
	" -tree <tree in Newick format>\n",
	" -names <2-columns file: species_name appendix>\n",
	"Example:\n",
	"$0 -tree <example_tree> -names <example_names>\n";
    die;
}
