#!/usr/bin/env perl 
use strict;
use warnings;

# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree STRMEV_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy


my $raxml="/data/ubastolla/BIN/SSCPE/raxml-ng";

my @trees=(
    "AA_JTT_FG_DNA2_GTR_G.bestTree",
    "AA_JTT_FG_DNA2_TVM_G.bestTree",
    "AA_STMTREV_FG_DNA2_TVM_G.bestTree",
    "AA_STMTREV_FG_DNA2_GTR_G.bestTree",
    "AA_JTT_FG_DNA_GTR_G.bestTree",
    "AA_JTT_FG_DNA_TVM_G.bestTree",
    "AA_STMTREV_FG_DNA_TVM_G.bestTree",
    "AA_STMTREV_FG_DNA_GTR_G.bestTree",
    #"AA_JTT_F_DNA_GTR.bestTree",
    #"AA_STMTREV_F_DNA_TVM.bestTree",
    "AAsyn_STMTREV_FG.bestTree",
    "AAsyn_JTT_FG.bestTree",
    "AA_STMTREV_FG.bestTree",
    "AA_STMTREV_F.bestTree",
    "AA_JTT_FG.bestTree",
    "AA_JTT_F.bestTree",
    "DNA_TVM_G.bestTree",
    "DNA_TVM.bestTree",
    "DNA_GTR_G.bestTree",
    #"DNAnoAA_GTR_G.bestTree"
    );

my $file_tree="";
my $msa="";
my $model="";
my $dir="";

for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-msa"){
	$i++; $msa=$ARGV[$i];
    }elsif($ARGV[$i] eq "-model"){
	$i++; $model=$ARGV[$i];
    }elsif($ARGV[$i] eq "-dir"){
	$i++; $dir=$ARGV[$i];
    }elsif($ARGV[$i] eq "-trees"){
	$i++; $file_tree=$ARGV[$i];
    }else{
	print "WARNING, unknown option $ARGV[$i]\n";
    }
}
if($msa eq "" || $model eq ""){help();}

my ($nsite, $ntaxa, $norm)=(0,0,0);
if(!-e $msa){
    print "ERROR, MSA file $msa does not exist\n"; die;
}else{
    open(my $fh, '<', $msa);
    my $row = <$fh>;
    chomp $row;
    my @word=split(/\s+/, $row);
    $ntaxa=$word[0]; $nsite=$word[1];
    print "$ntaxa sequences with $nsite sites\n";
    $norm=(2*$ntaxa-3)*$nsite;
}
my $S=Entropy_model($model);

# Reading names of trees
my $ntree=scalar(@trees);
if(-e $file_tree){
    print "Reading trees in $file_tree\n";
    my $t;
    for($t=0; $t<$ntree; $t++){$trees[$t]="";}
    open(my $fh, '<', $file_tree);
    $t=0;
    while (my $row = <$fh>){
	chomp $row; $trees[$t]=$row; $t++;
    }
    close $fh;
    $ntree=$t;
}else{
    print "Using pre-defined tree topologies\n";
}

# Creating directory
if($dir eq ""){$dir=Set_dir($model, $msa);}
my $maindir="../";
if(-e $dir && !-d $dir){
    print "WARNING, $dir is a file using current directory\n";
    $dir="."; $maindir="./";
}elsif(!-d $dir){
    print "Creating directory $dir\n";
    `mkdir $dir`;
}else{
    print "Using existing directory $dir\n";
}
print "\nMoving to folder $dir\n";
chdir($dir);


# Branch length name
my $name_msa=Remove_extension($msa, 1);
my $mod=Remove_extension($model, 1);
my $branch=".br.${name_msa}_${mod}";
print "branch length type: $branch\n";

my $free_t=0;
my @ll_t; my @BIC_t; my @tree_name; my @brlen_t;
my $t=0;
foreach my $tree(@trees){
    my $maintree=${maindir}.$tree;
    if(!-e $maintree){
	print "ERROR, $maintree does not exist revise list of trees\n";
	die;
    }
    my $name=Remove_extension($tree, 1);
    my $msa_new=$name.$branch;
    my $tree_t=$msa_new.".raxml.bestTree";
    my $tree_new=$msa_new.".bestTree";
 
    if(!-e $tree_t && !-e $tree_new){
	print "New MSA file name: $msa_new\n";
	`cp ${maindir}$msa $msa_new`;
	my $copy_tree=0;
	if(!-e $tree){
	    `cp $maintree $tree`; $copy_tree=1;
	}
	my $copy_mod=0;
	if(-e ${maindir}.$model && !-e $model){
	    print "Copying ${maindir}$model\n";
	    `cp ${maindir}$model $model\n`;
	    $copy_mod=1;
	}

	my $command="$raxml --evaluate --outgroup M_can ".
	    "--tree $tree  --model $model --msa $msa_new\n";
	print $command;
	`$command`;
	`rm -f ${msa_new}*.startTree`;
	`rm -f ${msa_new}*.mlTrees`;
	`rm -f ${msa_new}*.rba`;
	`rm -f ${msa_new}`;
	if($copy_tree){`rm -f $tree`;}
	if($copy_mod){`rm -f $model`;}
    }

    my $input;
    my $log=$msa_new.".raxml.log";
    my $log_new=$msa_new.".log";
    if(-e $log){$input=$log;}
    elsif(-e $log_new){$input=$log_new;}
    else{print "ERROR, neither $log nor $log_new exist\n"; next;}
    my ($log_lik, $AIC, $AICc, $BIC, $free, $raxml_comm)=Read_log($input);
    if(!-e $log_new){
	open(my $fo, '>', $log_new);
	print $fo "RAxML-NG was called as follows:\n\n$raxml_comm\n";
	print $fo "[00] Loaded alignment with $ntaxa taxa and $nsite sites\n";
	print $fo "Final LogLikelihood: $log_lik\n";
	print $fo "AIC score: $AIC / AICc score: $AICc / BIC score: $BIC\n";
	print $fo "Free parameters (model + branch lengths): $free\n";
	close $fo;
	`rm -f $log`;
    }
    $tree_name[$t]=$name;
    $ll_t[$t]=$log_lik/$norm;
    $BIC_t[$t]=$BIC/$norm;
    $free_t=$free;
    
    if(-e $tree_t){$input=$tree_t;}
    elsif(-e $tree_new){$input=$tree_new;}
    else{print "ERROR, neither $tree_t nor $tree_new exist\n"; next;}
    my ($b1, $nb) = Get_tree_length($input);
    $brlen_t[$t]=$b1/$nb;

    if(-e $tree_t){`mv $tree_t $tree_new`;}
    $t++;
}

my $output="Regmlame_${name_msa}_${mod}.txt";
print "Writing $output\n";
open(my $fo, '>', $output);

my $nn=$t;
my ($r, $slope, $offset)=Regression(\@brlen_t, \@ll_t, $nn);
my $out="# Correlation between br.len/nbr and log.lik/(ns*nbr):";
$out=$out.sprintf(" %.3f", $r)." slope=".sprintf(" %.3g", $slope).
    " offset=".sprintf(" %.3g", $offset)." n= $nn\n";
print $out;
print $fo $out;
my $coeff_slope=1.00;
$slope*=$coeff_slope;
print $fo "# msa= $name_msa  ntaxa= $ntaxa nsite= $nsite\n";
print $fo "# substitution model= $mod $free_t fitted param.\n";
print $fo "#1=tree 2=BIC/S 3=loglik/(ns*nbr*S) 4=sum_br_len/nbr ",
    "5=reg=-loglik/(ns*nbr*S)+",
    sprintf("%.4f",$slope),"*sum_br/nbr\n";
print $fo "# slope=${coeff_slope}*fit_slope\n";

my $min_reg=-1; my $min_BIC=-1;
my @reg;
for(my $t=0; $t<$nn; $t++){
    my $out=$tree_name[$t];
    $out=$out.sprintf("\t%.5g", $BIC_t[$t]/$S);
    $out=$out.sprintf("\t%.5g", $ll_t[$t]/$S);
    $out=$out.sprintf("\t%.5g", $brlen_t[$t]);
    $reg[$t]=-$ll_t[$t]+$slope*$brlen_t[$t]+$offset;
    $out=$out.sprintf("\t%.5g", $reg[$t]/$S);
    print $fo $out,"\n";
    if($min_reg<0 || $reg[$t]<$reg[$min_reg]){$min_reg=$t;}
    if($min_BIC<0 || $BIC_t[$t]<$BIC_t[$min_BIC]){$min_BIC=$t;}
}
print $fo "#min_reg: $tree_name[$min_reg] ",
    sprintf("%.5g\n",$reg[$min_reg]/$S);
print $fo "#min_BIC: $tree_name[$min_BIC] ",
    sprintf("%.5g\n",$BIC_t[$min_BIC]/$S);

close $fo;


sub Entropy_model{
    my $model=$_[0];
    my $S=0;
    if(-e $model){
	my $norm=0;
	open(my $fh, '<', $model) or die "Could not open $model\n";
	while(my $row = <$fh>){
	    chomp $row;
	    my @word=split(/\s+/, $row);
	    if(scalar(@word)<4){next;}
	    my @word2=split(/-/, $word[3]);
	    my $l=$word2[1]-$word2[0]+1;
	    my $mod=substr($row, 0, 3);
	    if($mod eq "TVM" || $mod eq "GTR"){ # DNA
		$S+=$l*log(4); $norm+=$l;
	    }else{ # AA
		$S+=$l*log(20); $norm+=$l;
	    }
	}
	close $fh;
	if($norm){$S/=$norm;}
	print "Reading $model S= ",sprintf("%.3f\n", $S);
    }else{
	my $mod=substr($model, 0, 3);
	if($mod eq "TVM" || $mod eq "GTR"){$S=log(4);}
	elsif($mod eq "JTT" || $mod eq "STM"){$S=log(20);}
	print "S= ",sprintf("%.3f\n", $S);
    }
    return($S);
}

sub Get_tree_length{
    open(my $fh, '<', $_[0]);
    my $row = <$fh>;
    close $fh;
    chomp $row;
    my $b1=0; my $nb=0; my $ib=-1; # my $b2=0; 
    for(my $i=0; $i<length($row); $i++){
	my $x=substr($row, $i, 1);
	if($x eq ":"){
	    $ib=$i+1;
	}elsif(($x eq ")" || $x eq "," || $x eq ";") && $ib >=0){
	    my $l=$i-$ib;
	    $b=substr($row, $ib, $l);
	    $nb++; $b1+=$b;
            # $b2+=$b*$b; 
	    $ib=-1;
	}
    }
    # Do not accept if all branch lengths are equal (it happens)
    # if($nb){$b2-=($b1*$b1)/$nb};
    # if($b2 <= 0.000001*$nb){$nb=0;}

    return ($b1, $nb); # $b2, 
}

sub Regression{
    my ($x, $y, $n)=@_;
    my $x1=0; my $x2=0; my $y1=0; my $y2=0; my $xy=0;
    for(my $i=0; $i<$n; $i++){
	my $xx=$x->[$i]; my $yy=$y->[$i];
	$x1+=$xx; $x2+=$xx*$xx; 
	$y1+=$yy; $y2+=$yy*$yy;
	$xy+=$xx*$yy;
    }
    $x1/=$n; $x2=$x2/$n-$x1*$x1;
    $y1/=$n; $y2=$y2/$n-$y1*$y1;
    $xy=$xy/$n-$x1*$y1;
    my $r=$xy/sqrt($x2*$y2);
    my $slope=$xy/$x2;
    my $offset=$y1-$slope*$x1;
    return($r, $slope, $offset);
}
 
sub Remove_extension{
    my ($name, $l)=@_;
    if($l eq ""){$l=1;}
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

# ($log_lik, $AIC, $AICc, $BIC, $free, $raxml_comm)
sub Read_log{
    my ($log_lik, $AIC, $AICc, $BIC, $free, $raxml_comm)=(0,0,0,0,0,0);
    my $input=$_[0];
    open(my $fh, '<', $input) or die "Could not open $input\n";
    my $k=3;
    while(my $row = <$fh>){
	chomp $row;
	my @word=split(/\s+/, $row);
	if(scalar(@word)==0){next;}
	if($word[0] eq "RAxML-NG"){
	    $k=0;
	}elsif($word[0] eq "Final"){
	    $log_lik=sprintf("%.1f",$word[2]);
	}elsif($word[0] eq "Free"){
	    $free=$word[6];
	}elsif($word[0] eq "AIC"){
	    $AIC=sprintf("%.1f",$word[2]);
	    $AICc=sprintf("%.1f",$word[6]);
	    $BIC=sprintf("%.1f",$word[10]);
	}elsif($k==1){
	    $raxml_comm=$row;
	}
	$k++;
    }
    close $fh; 
    return ($log_lik, $AIC, $AICc, $BIC, $free, $raxml_comm);
}

sub help(){
    print 
	"\nProgram $0, author Ugo Bastolla <ubastolla\@cbm.csic.es>\n",
	"for an input msa and model and a list of trees ",
	"it computes the normalized log.likelihood and mean branch length ",
	"of each tree, it fits the log.likelihood versus the br.length ",
	"obtaining the parameter lambda, and computes ",
	"Regmlame=norm.log.lik-Lambda*mean_br_len ",
	"for each tree, selecting the tree with minimum Regmlame score.\n",
	"It prints the results in the table Regmlame_msa_model.txt\n",
	"It needs as input an msa, a model and optionally a list of trees\n",
	"USAGE: $0 -msa <msa in phylip format> ",
	"-model <model used by raxml-ng>\n",
	"-tree <list of trees in Newick format>\n",
	"-dir <Folder where results are stored>\n",
	"Example: $0 -msa DNA.phy -model GTR+G -tree trees.list\n\n";
    die;
}

sub Set_dir{
    my ($model, $msa)=@_;
    my @word=split(/\./,$model); 
    if(scalar(@word)>1){
	return($word[0]); # .partition
    }else{
	my $dir;
	@word=split(/\./,$msa);
	if($word[0] eq "AAnores"){$dir="AA";}
	else{$dir=$word[0];} # AAsyn DNA DNA noAA

	@word=split(/\+/,$model);
	$dir=$dir."_".$word[0];
	if(scalar(@word)>1){
	    if($word[1] eq "FC"){$word[1]="F";}
	    $dir=$dir."_".$word[1];
	}
	if(scalar(@word)==3){$dir=$dir.$word[2];}
	return($dir);
    }
}


