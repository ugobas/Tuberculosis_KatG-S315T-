#!/usr/bin/env perl 
use strict;
use warnings;

# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree STRMEV_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy

my $regmlame="/data/ubastolla/TUBERCULOSIS/SOURCE/script_regmlame.pl";

my ($m_min, $m_max, $name)=(0, 20, ""); # exclude DNAnoAA
my @group_max=(9,16,22);
my @group_name=("AA_DNA","AA","DNA");
my $ngroup=scalar(@group_name);
#my ($m_min, $m_max, $name)=(0, 9, "_AA_DNA");
#my ($m_min, $m_max, $name)=(10, 16, "_AA");
#my ($m_min, $m_max, $name)=(17, 22, "_DNA");

my @models; my @msa;
$msa[0]="AA_DNA.phy"; $models[0]="AA_STMTREV_F_DNA_TVM.partition";
$msa[1]="AA_DNA.phy"; $models[1]="AA_STMTREV_FG_DNA_TVM_G.partition";
$msa[2]="AA_DNA.phy"; $models[2]="AA_STMTREV_FG_DNA_GTR_G.partition";
$msa[3]="AA_DNA.phy"; $models[3]="AA_STMTREV_FG_DNA2_TVM_G.partition";
$msa[4]="AA_DNA.phy"; $models[4]="AA_STMTREV_FG_DNA2_GTR_G.partition";
$msa[5]="AA_DNA.phy"; $models[5]="AA_JTT_F_DNA_GTR.partition",
$msa[6]="AA_DNA.phy"; $models[6]="AA_JTT_FG_DNA_GTR_G.partition";
$msa[7]="AA_DNA.phy"; $models[7]="AA_JTT_FG_DNA_TVM_G.partition";
$msa[8]="AA_DNA.phy"; $models[8]="AA_JTT_FG_DNA2_GTR_G.partition";
$msa[9]="AA_DNA.phy"; $models[9]="AA_JTT_FG_DNA2_TVM_G.partition";
$msa[10]="AAnores.phy";$models[10]="STMTREV+F+G";
$msa[11]="AAnores.phy";$models[11]="JTT+FC+G";
$msa[12]="AAnores.phy";$models[12]="STMTREV+FC";
$msa[13]="AAnores.phy";$models[13]="JTT+FC";
$msa[14]="AAnores.phy";$models[14]="STMTREV";
$msa[15]="AAsyn.phy";  $models[15]="STMTREV+FC+G";
$msa[16]="AAsyn.phy";  $models[16]="JTT+FC+G";
$msa[17]="DNA.phy";    $models[17]="TVM+G";
$msa[18]="DNA.phy";    $models[18]="GTR+G";
$msa[19]="DNA.phy";    $models[19]="TVM+G";
$msa[20]="DNA.phy";    $models[20]="GTR+G";
$msa[21]="DNAnoAA.phy";$models[21]="TVM+G";
$msa[22]="DNAnoAA.phy";$models[22]="GTR+G";

my @name_t; my @num_t; my $ntree=0;
my @reg_t; my @reg_1; my @reg_2; my @group_reg;
my @BIC_t; my @BIC_1; my @BIC_2; my @group_BIC;
my @len_t; my @len_1; my @len_2;
my @rank_BIC; my @rank_BIC_1; my @rank_BIC_2; 
my @rank_reg; my @rank_reg_1; my @rank_reg_2; 
my @missing;

my @rank_BIC_mt; my @rank_reg_mt;
my @mod_name;

my $dumm=-1;
for(my $t=0; $t<$m_max; $t++){
    for(my $k=0; $k<$ngroup; $k++){
	$group_reg[$t][$k]=$dumm;
	$group_BIC[$t][$k]=$dumm;
    }
}

my $nm=0;
for(my $m=$m_min; $m<=$m_max; $m++){
    my $name_msa=Remove_extension($msa[$m], 1);
    my $mod=Remove_extension($models[$m], 1);
    $mod_name[$m]=${name_msa}."_".${mod};
    my $input="Regmlame_${name_msa}_${mod}.txt";
    open(my $fh, '<', $input) or die "Could not open $input\n";
    print "Reading $input\n";
    for(my $t=0; $t<$ntree; $t++){
	$missing[$t]=1; $BIC_t[$t]=1000; $reg_t[$t]=1000;
    }
    while(my $row = <$fh>){
	if(substr($row, 0, 1) eq "#"){next;}
	chomp $row;
	my @word=split(/\t/, $row);
	my $tree=$word[0];
	my $t=Index_tree($tree);
	$missing[$t]=0;
	$num_t[$t]++;
	my $BIC=$word[1];
	$BIC_t[$t]=$BIC;
	$BIC_1[$t]+=$BIC;
	$BIC_2[$t]+=$BIC*$BIC;
	my $len=$word[3];
	$len_t[$t]=$len;
	$len_1[$t]+=$len;
	$len_2[$t]+=$len*$len;
	my $reg=$word[4];
	$reg_t[$t]=$reg;
	$reg_1[$t]+=$reg;
	$reg_2[$t]+=$reg*$reg;
# minimum BIC
	my $k=Set_group($m, \@group_max, $ngroup);
	if($group_BIC[$t][$k] eq $dumm || $BIC<$group_BIC[$t][$k]){
	    $group_BIC[$t][$k]=$BIC;
	}
	if($group_reg[$t][$k] eq $dumm || $reg<$group_reg[$t][$k]){
	    $group_reg[$t][$k]=$reg;
	}
    }
    close $fh;
    Rank_score(\@rank_BIC, \@BIC_t, $ntree);
    Rank_score(\@rank_reg, \@reg_t, $ntree);
    for(my $t=0; $t<$ntree; $t++){
	if($missing[$t]){next;}
	$rank_BIC_mt[$m][$t]=$rank_BIC[$t];
	$rank_BIC_1[$t]+=$rank_BIC[$t];
	$rank_BIC_2[$t]+=$rank_BIC[$t]*$rank_BIC[$t];
	$rank_reg_mt[$m][$t]=$rank_reg[$t];
	$rank_reg_1[$t]+=$rank_reg[$t];
	$rank_reg_2[$t]+=$rank_reg[$t]*$rank_reg[$t];
    }
    $nm++;
}
my ($diff_1, $diff_2)=(0,0);
my $output="Regmlame_ave${name}.txt";
open(my $fo, '>', $output);
print "Writing $output\n";

print $fo "#tree",
    "\t<reg>\tSEM\tt\t<BIC>\tSEM\t<len>\tSEM";
my $l=9;
for(my $k=0; $k<$ngroup; $k++){
    print $fo "\t$l=BIC_$group_name[$k]"; $l++;
}
for(my $k=0; $k<$ngroup; $k++){
    print $fo "\t$l=reg_$group_name[$k]"; $l++;
}
print $fo
    "\trank_reg\trank_BIC", #\tSD\tSD
    "\tnum\n";
my $sn=sqrt($num_t[0]);
for(my $t=0; $t<$ntree; $t++){
    Ave_SD($rank_reg_1[$t], $rank_reg_2[$t], $num_t[$t]);
    Ave_SD($rank_BIC_1[$t], $rank_BIC_2[$t], $num_t[$t]);
    Ave_SD($reg_1[$t], $reg_2[$t], $num_t[$t]);
    Ave_SD($len_1[$t], $len_2[$t], $num_t[$t]);
    Ave_SD($BIC_1[$t], $BIC_2[$t], $num_t[$t]);
    print $fo $name_t[$t],
    sprintf("\t%.3g", $reg_1[$t]),
    sprintf("\t%.2g", $reg_2[$t]/$sn),
    sprintf("\t%.3g", $reg_1[$t]*$sn/$reg_2[$t]),
    sprintf("\t%.4g", $BIC_1[$t]),
    sprintf("\t%.2g", $BIC_2[$t]/$sn),
    sprintf("\t%.3g", $len_1[$t]),
    sprintf("\t%.2g", $len_2[$t]/$sn);
for(my $k=0; $k<$ngroup; $k++){
    print $fo sprintf("\t%.5g",$group_BIC[$t][$k]);
}
for(my $k=0; $k<$ngroup; $k++){
    print $fo sprintf("\t%.4g",$group_reg[$t][$k]);
}
print $fo
    sprintf("\t%.3g", $rank_reg_1[$t]),
    #sprintf("\t%.2g", $rank_reg_2[$t]),
    sprintf("\t%.3g", $rank_BIC_1[$t]),
    #sprintf("\t%.2g", $rank_BIC_2[$t]),
    sprintf("\t%d", $num_t[$t]),
    "\n";
    my $diff=$rank_BIC_2[$t]-$rank_reg_2[$t];
    #my $diff=$rank_BIC_2[$t]*$rank_BIC_2[$t]-$rank_reg_2[$t]*$rank_reg_2[$t];
    $diff_1+=$diff; $diff_2+=$diff*$diff;
}
Ave_SD($diff_1, $diff_2, $ntree);
print $fo "# SD(rank_BIC)-SD(rank_reg): ",
    sprintf("mean= %.4g SEM= %.4g\n", $diff_1, $diff_2/sqrt($ntree));
close $fo;


$output="Regmlame_rank_BIC${name}.txt";
open($fo, '>', $output);
print "Writing $output\n";
print $fo "# rank_BIC\n";
print $fo "#tree";
for(my $k=$m_min; $k<=$m_max; $k++){print $fo "\t",$mod_name[$k];} 
print $fo " ave\n";
for(my $t=0; $t<$ntree; $t++){
    print $fo $name_t[$t];
    for(my $k=$m_min; $k<=$m_max; $k++){
	printf $fo "\t${rank_BIC_mt[$k][$t]}";
    }
    print $fo sprintf("\t%.3g", $rank_BIC_1[$t]);
    print $fo "\n";
}
close $fo;

$output="Regmlame_rank_reg${name}.txt";
open($fo, '>', $output);
print "Writing $output\n";
print $fo "# rank_reg\n";
print $fo "#tree";
for(my $k=$m_min; $k<=$m_max; $k++){print $fo "\t",$mod_name[$k];}
print $fo " ave\n";
for(my $t=0; $t<$ntree; $t++){
    print $fo $name_t[$t];
    for(my $k=$m_min; $k<=$m_max; $k++){
	printf $fo "\t${rank_reg_mt[$k][$t]}";
    }
    print $fo sprintf("\t%.3g", $rank_reg_1[$t]);
    print $fo "\n";
}
close $fo;


sub Index_tree{
    my $tree=$_[0];
    for(my $t=0; $t<$ntree; $t++){
	if($tree eq $name_t[$t]){return($t);}
    }
    $name_t[$ntree]=$tree;
    $num_t[$ntree]=0;
    $reg_1[$ntree]=0;
    $reg_2[$ntree]=0;
    $BIC_1[$ntree]=0;
    $BIC_2[$ntree]=0;
    $rank_BIC_1[$ntree]=0;
    $rank_BIC_2[$ntree]=0;
    $rank_reg_1[$ntree]=0;
    $rank_reg_2[$ntree]=0;
    $ntree++;
}

sub Rank_score{
    my ($rank, $score, $n)=@_;
    my @ranked;
    for(my $i=0; $i<$n; $i++){$ranked[$i]=0;}
    for(my $k=0; $k<$n; $k++){
	my $irank=-1;
	for(my $i=0; $i<$n; $i++){
	    if($ranked[$i]){next;}
	    if($irank<0 || $score->[$i]<$score->[$irank]){$irank=$i;}
	}
	$rank->[$irank]=$k;
	$ranked[$irank]=1;
    }
}

sub Ave_CoV{ # sum sum_2 n
    my $n=$_[2];
    $_[0]/=$n;
    $_[1]=sqrt($_[1]/($n*$_[0]*$_[0])-1.0);
}

sub Ave_SD{ # sum sum_2 n
    my $n=$_[2];
    $_[0]/=$n;
    if($n>1){
	$_[1]=($_[1]-$n*$_[0]*$_[0])/($n-1);
    }else{
	$_[1]=$_[0]*$_[0];
    }
    $_[1]=sqrt($_[1]);
}

sub Remove_extension{
    my ($name, $l)=@_;
    if($l eq ""){$l=1;}
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

sub Set_group{
    my ($m, $group_max, $ngroup)=@_;
    for(my $k=0; $k<$ngroup; $k++){
	if($m<=$group_max->[$k]){return($k);}
    }
    return($ngroup-1);
}
