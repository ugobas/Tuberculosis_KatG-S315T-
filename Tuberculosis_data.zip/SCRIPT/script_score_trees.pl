#!/usr/bin/env perl 
use strict;
use warnings;

# --evaluate --tree JTT_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy
# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree STRMEV_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy
# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree GTR_G4DNA.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy
#/data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree TVM_G4DNA.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy

my $raxml="/data/ubastolla/BIN/SSCPE/raxml-ng";

my @sets=("mut.aa.aanores.phy","mut.aa.aanores.phy",
	  "all_dna.phy","all_dna.phy",);
my @models=("STMTREV+FC+G4","JTT+FC+G4","GTR+G4","TVM+G4");
my @trees=("JTT_F_G4Amino.bestTree","STMTREV_F_G4Amino.bestTree",
	   "AA_nosyn_STMTREV_FG.bestTree",
	   "GTR_G4DNA.bestTree","TVM_G4DNA.bestTree",
	   "DNA_noAA_GTR.bestTree");

my $k=0;
foreach my $model(@models){
    my $set=$sets[$k]; $k++;
    foreach my $tree(@trees){
	my $name=Remove_extension($tree, 1);
	my $dir=$name."_".$model;
	`mkdir $dir`;
	`cp $tree $dir`;
	`cp $set $dir`;
	chdir($dir);
	my $script="script_${name}_${model}";
	open(my $fo, '>', $script);
	print "Writing $script\n";
	print $fo "$raxml --evaluate --outgroup M_can ",
	"--tree $tree  --model $model --msa $set\n";
	print $fo "rm -f *.startTree\n";
	print $fo "rm -f *.rba\n";
	close $fo;
	`chmod u+x $script`;
	`./$script`;
	chdir("../");
    }
}

sub Remove_extension{
    my ($name, $l)=@_;
    if($l eq ""){$l=1;}
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}




