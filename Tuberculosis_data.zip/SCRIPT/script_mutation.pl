#!/usr/bin/env perl 
use strict;
use warnings;

my @NUC=("A","G","C","T");

my $genome="/data/ubastolla/TUBERCULOSIS/sequence.gb";

my @name; my $ntype=9; 
my $name_dna="mut.dna";
my $name_aa="mut.aa";
$name[0]=$name_aa.".S315T";
$name[1]=$name_aa.".resistant";
$name[2]=$name_dna.".secondary";
$name[3]=$name_aa.".aanores"; # not resistance
$name[4]=$name_aa.".nosyn"; # all
$name[5]=$name_dna.".syn";
$name[6]=$name_dna.".intergenic";
$name[7]=$name_dna.".dna";
$name[8]=$name_dna.".all";

my @S315T=("katG_S315T");
my @resistant=(
    "katG_E10G", "katG_C20S", "katG_D63E",
    "katG_R104L", "katG_W107R", "katG_H108E", "katG_H108Q", "katG_A110V",
    "katG_N138D", "katG_N138S", "katG_A139P", "katG_A139V", "katG_L148R",
    "katG_Y229F", "katG_W300G",
    "katG_T262R", "katG_H270Q", "katG_T275P", "katG_W328G",
    "katG_Y337C", "katG_A350S",
    "katG_S315G", "katG_S315I", "katG_S315N", "katG_S315R",
    #"katG_S315T",
    "katG_W321G", "katG_W321F", "katG_D381G",
    #"katG_R463L",
    "katG_L587M", "katG_L587P", "katG_L619P",
    "katG_G629S", "katG_L634F", "katG_D735N", "katG_D735A",
    "accD6_E224D",
    "echa6", # cell wall biosynthesis (Jonathan)
    #"efpA", # INH ?
    "efpA_E520V",
    "eis", # KM?
    "embA",   # EMB
    "embB_M306V", "embB_M306I", # EMB
    "embC",  # EMB
    "ethA", "ethR", # ETH?
    "fabD_A3T",
    "fabG1",  # fabG-inhA operon (-15 and -34 nt) ETH
    "fadE24_Q85R",
    "fbpC",
    # "furA_S5P", # It may be secondary adaptation to S315T
    "gidB", # STR
    "gyrA", #gyrA_90, gyrA_91, gyrA_94, gyrB_538, gyrB_540 OFL
    "gyrB",
    "inhA_I21T", "inhA_*15*", "inh_*8*", # inhA promoter INH
    "iniB", # INH
    "iniA_P3A", "iniA_R537H", "iniC_W83G",
    "kasA", # INH?
    # "nat",  # INH inactivates INH 
    "nat_T175A",
    # "ndh",  # INH ?
    "ndh_R268H", "ndh_L104F", "ndh_E360K",
    "pncA", # PZA
    "rpoB_Q432K", # RMP, RIF
    "rpsA",  # STR (SM)
    "rpsL", # STR SM
    "rrs_*1401*", "rrs_*1402*", "rrs_*1484*", # STR
    "rrs_*1490*", # CM? 
    "whiB7", # STR?
    "Rv0340_V163I",
    "Rv1592c_G9D", "Rv1592c_P42L", "Rv1592c_V430A",
    "Rv1772_T4A"
);

my @secondary=(
   "ahpC", # Response to oxidative stress
   "furA", # Negative regulator of katG
   "oxyR'", # Positive regulator of katG. Inactivated in MTU
# oxyR-ahpC intergenic region INH 
   "sodA", # Rv3846 Superoxide dismutase; Destroys toxic superoxide anion radicals
   "sodC", # Rv<0432
   "IG_oxyR'_N_ahpc_N",
   "IG_katG_N_furA_C",
   "IG_furA_N_Rv1910c_C",
   "IG_Rv3845_C_sodA_N",
   "IG_Rv0431_C_sodC_C"
);
# other: ahpC, oxyR, kasA, iniB, fabG1, fbpC


my $dna=""; my $aa="";
if(scalar(@ARGV)<2){help();}
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-dna"){
	$i++; $dna=$ARGV[$i];
    }elsif($ARGV[$i] eq "-aa"){
	$i++; $aa=$ARGV[$i];
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
unless(-e $dna && -e $aa){
    print "ERROR, file $dna or $aa does not exist\n"; help();
}

my ($ngene, $l_genes, $l_inter, @genes) = Read_genome($genome);

my @mut_dna; my @name_seq_dna; my @seq_dna;
my ($name_dna_2, $nseq_dna, $nmut_dna) = 
    Read_mutations($dna,\@mut_dna,\@name_seq_dna,\@seq_dna,0,\@genes,$ngene);

my @name_seq_aa; my @seq_aa;
my ($name_aa_2, $nseq_aa, $nmut_aa) = 
    Read_mutations($aa,\@mut_dna,\@name_seq_aa,\@seq_aa,$nmut_dna,\@genes,$ngene);

my ($nres_S315T, $lres_S315T, @mut_res_S315T)=
    Read_resistant(\@S315T, "S315T", \@genes, $ngene);
my ($nres, $lres, @mut_res)=
    Read_resistant(\@resistant, "resistant", \@genes, $ngene);
my ($nsec, $lsec, @mut_sec)=
    Read_resistant(\@secondary, "secondary", \@genes, $ngene);

{
    my $nameout="set_size.txt";
    open(my $fo, '>', $nameout);
    print "Writing $nameout\n";
    my $l_genome=4411533;
    print $fo "Genome:\t$l_genome\n";
    print $fo "Genes:\t$l_genes\n";
    print $fo "Intergenic:\t$l_inter\n";
    my $l=$lres_S315T->[0]+$lres_S315T->[1]+$lres_S315T->[2];
    print $fo "S315T:\t$l\n";
    $l=$lres->[0]+$lres->[1]+$lres->[2];
    print $fo "Resistant:\t$l\n";
    $l=$lsec->[0]+$lsec->[1]+$lsec->[2];
    print $fo "Secondary:\t$l\n";
    my $syn=$l_genes/3;
    my $nosyn=3*$l_genes-$syn;
    $nosyn-=$lres->[0]-$lres_S315T->[0]-$lsec->[0];
    $syn-=$lres->[1]-$lres_S315T->[1]-$lsec->[1];
    $l_inter-=$lres->[2]-$lres_S315T->[2]-$lsec->[2];
    print $fo "Synonymous:\t$syn\n";
    print $fo "Non-synonymous:\t$nosyn\n";
    print $fo "Intergenic:\t$l_inter\n";
    close $fo;
    #die;
}

my @muts; my @alis; my @fm; my @fa; my @num;
my @seqnew;
for(my $i=0; $i<$ntype; $i++){
    $muts[$i]=$name[$i].".txt";
    $alis[$i]=$name[$i].".phy";
    print "Writing files ${alis[$i]} and ${muts[$i]}\n";
    for(my $n=0; $n<$nseq_dna; $n++){
	$seqnew[$i][$n]="";
    }
    $num[$i]=0;
}

for(my $i=0; $i<$nmut_dna; $i++){

    # type of mutation
    my @type=(-1,-1);
    if($mut_dna[$i][8] <0){ # intergenic
	$type[0]=6; # intergenic
        $type[1]=7; # dna
    }elsif($mut_dna[$i][3] eq $mut_dna[$i][4]){
	$type[0]=5; # synonymous
	$type[1]=7; # dna
    }else{ # non-synonymous mutation
        $type[1]=4; # amino acid
    }
    #print "Is ",$mut_dna[$i][1],"resistance gene?\n";
    my $j=Test_res(\@mut_dna, $i, \@mut_res_S315T, $nres_S315T, "S315T");
    if($j>=0){$type[0]=0; goto RECORD_MUT;}
    $j=Test_res(\@mut_dna, $i, \@mut_res, $nres, "resistance");
    if($j>=0){$type[0]=1; goto RECORD_MUT;}
    $j=Test_res(\@mut_dna, $i, \@mut_sec, $nsec, "secondary");
    if($j>=0){$type[0]=2; goto RECORD_MUT;}
    if($type[1]==4){
	$type[0]=3;
    	print "${mut_dna[$i][1]} ",
    	"${mut_dna[$i][3]}${mut_dna[$i][2]}${mut_dna[$i][4]} ",
    	"is a.a. mutation of unknown effect\n";
    }

RECORD_MUT:
    for(my $j=0; $j<2; $j++){
	if($type[$j]<0){next;}
	my $tj=$type[$j];
	my $nt=$num[$tj];
	my $out="$nt\t$mut_dna[$i][0]\t$mut_dna[$i][1]";
	my $k = $mut_dna[$i][8];
	if($tj <= 4 && $tj != 2 && $k>=0){ # amino acid
	    $out=$out."\t$mut_dna[$i][3]\t$mut_dna[$i][2]\t$mut_dna[$i][4]\n";
	    for(my $n=0; $n<$nseq_aa; $n++){
		substr($seqnew[$tj][$n],$nt,1) = substr($seq_aa[$n], $k, 1);
	    }
	}else{
	    $out=$out."\t$mut_dna[$i][6]\t$mut_dna[$i][5]\t$mut_dna[$i][7]\n";
	    for(my $n=0; $n<$nseq_dna; $n++){
		substr($seqnew[$tj][$n],$nt,1) = substr($seq_dna[$n], $i, 1);
	    }
	}
	open(my $fm, '>>', $muts[$tj]);
	print $fm $out;
	close $fm;
	$num[$tj]++;
    }
}

my $naa=$num[0]+$num[1]+$num[2]+$num[3];
my $ndna=$num[5]+$num[6];
print
    "$num[0] S315T resistance + ",
    "$num[1] other resistance mutations + ",
    "$num[2] secondary resistance mutations + ",
    "$num[3] non-synonymous mutations = ",
    "$num[4] amino acid changes, expected: $naa\n",
    "+ $num[5] synonymous mutations = ", $naa+$num[5],
    " genic mutations, expected: $nmut_aa\n";
print "+ $num[6] intergenic mutations = ",
    $naa+$ndna," expected: $nmut_dna\n";
print "$num[7] non-aa mutations, expected: $ndna\n";

my $nt1=$ntype-1;
open(my $fm, '>>', $muts[$nt1]);
my $nt=0;
for(my $k=0; $k<3; $k++){
    my $tj; my $partition;
    if($k==0){$tj=3; $partition="STMTREV+FC+G, nosynonym";}
    elsif($k==1){$tj=5; $partition="TVM+G, synonym";}
    elsif($k==2){$tj=6; $partition="TVM+G, intergenic";}
    for(my $i=0; $i<$num[$tj]; $i++){
	for(my $n=0; $n<$nseq_aa; $n++){
	    substr($seqnew[$nt1][$n],$nt,1) = substr($seqnew[$tj][$n],$i,1);
	}
	$nt++;
    }
    print $fm "$partition  = ",$num[$nt1]+1,"-",$nt,"\n";
    $num[$nt1]=$nt;
}
close $fm;

for(my $i=0; $i<$ntype; $i++){
    open(my $fa, '>', $alis[$i]);
    print $fa "$nseq_dna ${num[$i]}\n";
    for(my $n=0; $n<$nseq_dna; $n++){
	print $fa "${name_seq_dna[$n]} $seqnew[$i][$n]\n";
    }
    close $fa;
    print "wrote ${num[$i]} mutations in ${muts[$i]} and ${alis[$i]}\n";
}

Count_mutations(\@mut_dna, $nmut_dna);

exit;

#############################
# Subroutines

sub Count_mutations{
    my ($mut, $nmut)=@_;
    my @count; my @f;
    for(my $i=0; $i<4; $i++){
	$f[$i]=0; for(my $j=0; $j<4; $j++){$count[$i][$j]=0;}
    }
    for(my $i=0; $i<$nmut; $i++){
	my $nuc1=$mut->[$i][6];
        my $n1=Code_nuc($nuc1);
	my $nuc2=$mut->[$i][7];
	my $n2=Code_nuc($nuc2);
	$count[$n1][$n2]++;
    }
    for(my $i=0; $i<4; $i++){
	my $nuc1=$NUC[$i];
	my $ci=Code_nuc(Complementary($nuc1));
	for(my $j=0; $j<4; $j++){
	    if($i==$j){next;}
	    my $nuc2=$NUC[$j];
	    my $cj=Code_nuc(Complementary($nuc2));
	    my $num=($count[$i][$j]+$count[$ci][$cj]);
	    $f[$i]+=$num; $f[$ci]+=$num;
	    $count[$i][$j]=$num;
	    $count[$ci][$cj]=$num;
	}
    }

    my $out="all_mut.mut.txt";
    open(my $fo, '>', $out);
    print "Writing $out\n";
    for(my $i=0; $i<4; $i++){
	for(my $j=0; $j<4; $j++){
	    if($i==$j){next;}
	    $out=sprintf("$NUC[$i] -> $NUC[$j] = %.4f\n",
			 2*$count[$i][$j]/$f[$i]);
	    print $fo $out;
	}
    }
    close $fo;
}

sub Code_nuc{
    my $nuc=$_[0];
    for(my $i=0; $i<4; $i++){
	if($nuc eq $NUC[$i]){return($i);}
    }
    print "ERROR in Code_nuc, $nuc is not a nucleotide\n"; die;
}

sub Complementary{
    my $nuc=$_[0];
    if($nuc eq "A"){return("T");}
    elsif($nuc eq "G"){return("C");}
    elsif($nuc eq "C"){return("G");}
    elsif($nuc eq "T"){return("A");}
    print "ERROR in Complementary, $nuc is not a nucleotide\n"; die;
}

#my ($nres, @mut_res)= Read_resistant(\@resistant, "resistant");
sub Read_resistant{ #
    my ($mres, $what, $genes, $ngene) = @_;
    my $n=0; my @mut_res;
    my @l_res=(0,0,0); # 0=aa 1=syn 2=IG
    my($ng_res, $ig)=(0,0);
    my @gene_res=(); my @l_gene; my @written;
    foreach my $res (@$mres){
            my @word=split(/_/, $res);

            # Read name
	    if($word[0] eq "IG"){$mut_res[$n][1]=$res;}
	    else{$mut_res[$n][1]=$word[0];}

	    # Find gene and length
	    for($ig=$ng_res-1; $ig>=0; $ig--){
		if($gene_res[$ig] eq $mut_res[$n][1]){last;}
	    }
	    if($ig<0){
		$ig=$ng_res; $ng_res++;
		$gene_res[$ig]=$mut_res[$n][1];
		$l_gene[$ig]=0;
		$written[$ig]=0;
		my $gene=$gene_res[$ig];
		if($word[0] eq "IG"){$gene=$word[1];}
		my $jg;
		for($jg=0; $jg<$ngene; $jg++){
		    if($genes->[$jg][0] eq $gene){last;}
		}
		if($jg==$ngene){
		    print "ERROR, gene $gene not found\n";
		    next;
		}
		if($word[0] ne "IG"){
		    $l_gene[$ig]=$genes->[$jg][2]-$genes->[$jg][1];
		}else{
		    $l_gene[$ig]=$genes->[$jg+1][1]-$genes->[$jg][2];
		    if($l_gene[$ig]<0){
			print "ERROR, $genes->[$jg+1][1] - $genes->[$jg][2]\n";
			die;
		    }
		}
	    }
	    if($l_gene[$ig]==0){next;}

            if(scalar(@word)==2){
               $mut_res[$n][2]=substr($word[1], 1, length($word[1])-2);
               $mut_res[$n][3]=substr($word[1], 0, 1);
               $mut_res[$n][4]=substr($word[1], length($word[1])-1,1);
	       $l_res[0]++;
            }else{
               $mut_res[$n][2]="ALL"; $mut_res[$n][3]=""; $mut_res[$n][4]="";
	       if($written[$ig]==0){
		   if($word[0] eq "IG"){
		       $l_res[2]+=3*$l_gene[$ig];
		   }else{
		       my $naa=$l_gene[$ig]/3;
		       $l_res[0]+=8*$naa; # non-synonymous
		       $l_res[1]+=$naa; # synonymous
		   }
		   $written[$ig]=1;
	       }
            }
            print "${what}: ${mut_res[$n][1]} ",
            "${mut_res[$n][3]}${mut_res[$n][2]}${mut_res[$n][4]}\n";
            $n++;
    }
    print "$n $what mutations read\n"; 
    return($n, \@l_res, @mut_res);
}

# $j=Test_res(\@mut_dna, $i, \@mut_res, $nres, "resistance");
sub Test_res{
	my ($mut_dna, $i, $mut_res, $nres, $what)=@_;
	my $j;
	for($j=0; $j<$nres; $j++){
	    if($mut_dna->[$i][1] ne $mut_res->[$j][1]){next;}
            if($mut_res->[$j][2] ne "ALL" && $mut_res->[$j][2] ne $mut_dna->[$i][2]){next}
            if($mut_res->[$j][3] ne "*"   && $mut_res->[$j][3] ne $mut_dna->[$i][3]){next}
            if($mut_res->[$j][4] ne "*"   && $mut_res->[$j][4] ne $mut_dna->[$i][4]){next}
	    print "$mut_dna->[$i][1] ",
	    "$mut_dna->[$i][3]$mut_dna->[$i][2]$mut_dna->[$i][4] ",
	    "is known $what mutation\n";
	    return($j);
	}
	return(-1);
}

sub help(){
    print 
	"\nProgram $0, author Ugo Bastolla <ubastolla\@cbm.csic.es>\n",
	"It splits mutations in 4 classes: ",
	"known resistance, non-synonymous, synonymous, intergenic\n",
	"USAGE: $0 -aa <file with list of aa mutations> ",
	"-dna <file with list of dna mutations>\n",
	"Example: $0 -aa all_mut_amin.txt -dna all_mut_dna.txt\n\n";
    die;
}

sub Remove_spaces{
    my $s=$_[0]; my $ini=0; my $l=0;
    for($ini=0; $ini<length($s); $ini++){
	if(substr($s, $ini, 1) ne " "){last;} 
    }
    for($l=length($s)-1; $l>$ini; $l--){
	if(substr($s, $l, 1) ne " "){last;} 
    }
    my $len=$l+1-$ini;
    my $out=substr($s, $ini, $len);
    #print "\"$s\" -> \"$out\"\n"; #die;
    return($out);
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}

#my ($ngene, @genes) = Read_genome($genome);
sub Read_genome { #($genome);
    my $input=$_[0];
    if(!-e $input){
	print "ERROR, mutation file $input does not exist\n"; die;
    }

    my $l_genes=0;
    my $l_inter=0;
    my $last=0;

    print "Reading $input\n";
    open(my $fh, '<', $input);
    my $ngene=-1; my @gene=(); my $name="";
    while (my $row = <$fh>){
        my $l=length($row);
        if($l<22){next;}
	if(substr($row,5,4) eq "gene"){
	   if($ngene>=0){
	     print "gene: $gene[$ngene][0] $gene[$ngene][1]-$gene[$ngene][2]\n";
             # die;
           }
           $ngene++;
	   my $pos;
           if(substr($row, 21, 10) eq "complement"){
              $pos=substr($row, 32, $l-34);
              $gene[$ngene][3]=-1;
           }else{
              $pos=substr($row, 21, $l-22);
              $gene[$ngene][3]=1;
           }
           my @word=split('\.',$pos);
	   $gene[$ngene][1]=$word[0];
	   $gene[$ngene][2]=$word[2];
	   if($gene[$ngene][1]>$last){$l_inter+=$gene[$ngene][1]-$last;}
	   $last=$gene[$ngene][2];
           $name="";
        }elsif(substr($row, 21, 11) eq "/locus_tag=" && $name eq ""){
           $name=substr($row, 33, $l-35);
           $gene[$ngene][0]=$name;
        }elsif(substr($row, 21, 6) eq "/gene="){
           $name=substr($row, 28, $l-30);
           $gene[$ngene][0]=$name;
        }elsif(substr($row, 5, 3) eq "CDS"){
	    $l_genes+=$gene[$ngene][2]-$gene[$ngene][1];
	}
    }
    close $fh;
    return($ngene, $l_genes, $l_inter, @gene); 
}

sub Read_mutations{
    my ($input, $mut, $name_seq, $seq, $nmut_dna, $gene, $ngene) = @_;

    if(!-e $input){
	print "ERROR, mutation file $input does not exist\n"; die;
    }

    my $namefile=Remove_extension($input);
    my $ali=$namefile.".phy";
    if(!-e $ali){
	print "ERROR, alignment file $ali does not exist\n"; die;
    }
    print "Reading $input\n";


# all_mut_amin.txt
#1        1       dnaA    0       L -> V
#11       1533    None    None    G -> C

    open(my $fh, '<', $input);
    my @mutation; 
    # Structure of mutation:
    # [0] = position in genome;
    # [1] = gene;
    # [2] = aa position in gene;
    # [3] = wt aa;
    # [4] = mut aa;
    # [5] = position in gene;
    # [6] = wt_nuc;
    # [7] = mut nuc;
    # [8] = Position in aa MSA

    my $n=0; my $nd=0; my $nmut=0; my $dna="";
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row,0,1) eq "#"){
	    my @word=split(/\s+/, $row);
	    $nmut=$word[1]; $dna=$word[2];
	    print "$dna \n"; #if($dna ne "dna"){die;}
	    next;
	}
	my @word=split(/\t/, $row);
	for(my $k=0; $k<scalar(@word); $k++){
	    $word[$k] = Remove_spaces($word[$k]);
	}
	#print "$word[1] $word[2] $word[3] $word[4]\n"; #die;

	if($dna ne "dna"){ # second round, read amino acid
	    my $pos = $word[1]; # position in genome
	    my $j;
	    for($j=$nd; $j<$nmut_dna; $j++){
		if($mut->[$j][0] == $pos){$nd=$j; last;}
	    }
	    if($j==$nmut_dna){
		print "ERROR, position $pos not found in DNA file\n";
		die;
	    }
	    $mut->[$j][2] = int($mut->[$j][5]/3+1);
	    $mut->[$j][3] = substr($word[4], 0, 1);
	    $mut->[$j][4] = substr($word[4], 5, 1);
	    $mut->[$j][8] = $n;
	}else{

	    $mut->[$n][0]=$word[1]; # position in genome
	    $mut->[$n][1] = $word[2]; # Gene name
	    $mut->[$n][2] = -1;
	    $mut->[$n][5] = $word[3]; # Position in gene
	    $mut->[$n][6] = substr($word[4], 0, 1);
	    $mut->[$n][7] = substr($word[4], 5, 1);
	    $mut->[$n][8] = -1;
	    #print $mut->[$n][0]," ",$mut->[$n][1]," ",
		#$mut->[$n][6],$mut->[$n][5],$mut->[$n][7],"\n";
	    #die;
	}
	$n++;
    }
    close $fh;
    print "$n $dna mutations read in $input\n";
    if($n != $nmut){
	print "WARNING, $nmut mutations expected\n";
	$nmut=$n;
    }

    if($dna eq "dna"){
        my $igene=0;
	for(my $j=0; $j<$nmut; $j++){
	    if($mut->[$j][1] ne "None"){next;} # Intergenic
            my $pos=$mut->[$j][0]; my $i;
            for($i=$igene; $i<$ngene; $i++){
	        if($gene->[$i][1]>$pos){last;}
            }
            my $gene1; my $gene2; my $dpos="";
            if($i<$ngene){
	       $gene2=$gene->[$i][0];
               if($gene->[$i][3]>0){
		   $gene2=$gene2."_N";
		   $dpos=$gene->[$i][1]-$pos;
	       }else{
		   $gene2=$gene2."_C";
	       }
            }else{$gene2="None";}
            $i--;
            if($i>=0){
	       $gene1=$gene->[$i][0];
               if($gene->[$i][3]>0){
		   $gene1=$gene1."_C";
	       }else{
		   $gene1=$gene1."_N";
		   my $d=$pos-$gene->[$i][1];
		   if($dpos eq "" || $d<$dpos){$dpos=$d;}
	       }
            }else{$gene1="None";}
            if($gene->[$i][1] >= $pos){
               print "ERROR, gene last pos $gene->[$i][2] > $pos\n"; die;
            }
            if($i > $igene){$igene=$i;}
	    if($dpos eq ""){
		$dpos = $gene->[$i+1][1]-$pos;
		my $d = $pos-$gene->[$i][1];
		if($d<$dpos){$dpos=$d;}
	    }
            $mut->[$j][1]="IG_${gene1}_${gene2}";
	    $mut->[$j][5]=$dpos;
	    print "Intergenic mutation at pos $mut->[$j][0]: $mut->[$j][1]\n";
	    #die;
	}
    }

    my $ncol=0; my $nseq=0; my $s=-1;
    open($fh, '<', $ali); 
    while (my $row = <$fh>){
	chomp $row;
	my @word=split(/\s+/, $row);
	if($s<0){
	    $nseq=$word[0]; $ncol=$word[1]; $s++;
	    if($ncol != $nmut){
		print "ERROR, $nmut mutations read in $input ",
		"but $ncol columns are present in $ali\n"; die;
	    }
	    next;
	}
	$name_seq->[$s]=$word[0];
	$seq->[$s]=$word[1];
	$s++;
    }
    close $fh;
    print "$s sequences read in $ali\n";
    if($s != $nseq){
	print "ERROR, $nseq sequences expected but $s found\n"; die;
    }

    return($namefile, $nseq, $nmut);
}
