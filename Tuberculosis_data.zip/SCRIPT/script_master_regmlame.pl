#!/usr/bin/env perl 
use strict;
use warnings;

# /data/ubastolla/BIN/SSCPE/raxml-ng --evaluate --tree STRMEV_F_G4Amino.bestTree --outgroup M_can --model JTT+F+G4 --msa all_mut_amin.phy


my $regmlame="/data/ubastolla/TUBERCULOSIS/SOURCE/script_regmlame.pl";

my @models; my @msa;
$msa[0]="AA_DNA.phy"; $models[0]="AA_STMTREV_F_DNA_TVM.partition";
$msa[1]="AA_DNA.phy"; $models[1]="AA_STMTREV_FG_DNA_TVM_G.partition";
$msa[2]="AA_DNA.phy"; $models[2]="AA_STMTREV_FG_DNA_GTR_G.partition";
$msa[3]="AA_DNA.phy"; $models[3]="AA_STMTREV_FG_DNA2_TVM_G.partition";
$msa[4]="AA_DNA.phy"; $models[4]="AA_STMTREV_FG_DNA2_GTR_G.partition";
$msa[5]="AA_DNA.phy"; $models[5]="AA_JTT_F_DNA_GTR.partition",
$msa[6]="AA_DNA.phy"; $models[6]="AA_JTT_FG_DNA_GTR_G.partition";
$msa[7]="AA_DNA.phy"; $models[7]="AA_JTT_FG_DNA_TVM_G.partition";
$msa[8]="AA_DNA.phy"; $models[8]="AA_JTT_FG_DNA2_GTR_G.partition";
$msa[9]="AA_DNA.phy"; $models[9]="AA_JTT_FG_DNA2_TVM_G.partition";
$msa[10]="AAnores.phy";$models[10]="STMTREV+F+G";
$msa[11]="AAnores.phy";$models[11]="JTT+FC+G";
$msa[12]="AAnores.phy";$models[12]="STMTREV+FC";
$msa[13]="AAnores.phy";$models[13]="JTT+FC";
$msa[14]="AAnores.phy";$models[14]="STMTREV";
$msa[15]="AAsyn.phy";  $models[15]="STMTREV+FC+G";
$msa[16]="AAsyn.phy";  $models[16]="JTT+FC+G";
$msa[17]="DNAnoAA.phy";$models[17]="TVM+G";
$msa[18]="DNAnoAA.phy";$models[18]="GTR+G";
$msa[19]="DNA.phy";    $models[19]="TVM+G";
$msa[20]="DNA.phy";    $models[20]="GTR+G";
$msa[21]="DNA.phy";    $models[21]="TVM+G";
$msa[22]="DNA.phy";    $models[22]="GTR+G";

my $k=0;
foreach my $model(@models){
    my $dir=Set_dir($model, $msa[$k]);
    my $command=$regmlame." -msa $msa[$k] -model $model -dir $dir\n";
    print $command;
    #`$command`;
    my $script="script_$k";
    open(my $fo, '>', $script);
    print $fo $command;
    close $fo;
    `chmod u+x $script`;
    `qsubmit.pl -q x86_64 -n 4 -s $script`;
    $k++;
}

sub Set_dir{
    my ($model, $msa)=@_;
    my @word=split(/\./,$model); 
    if(scalar(@word)>1){
	return($word[0]); # .partition
    }else{
	my $dir;
	@word=split(/\./,$msa);
	if($word[0] eq "AAnores"){$dir="AA";}
	else{$dir=$word[0];} # AAsyn DNA DNA noAA

	@word=split(/\+/,$model);
	$dir=$dir."_".$word[0];
	if(scalar(@word)>1){
	    if($word[1] eq "FC"){$word[1]="F";}
	    $dir=$dir."_".$word[1];
	}
	if(scalar(@word)==3){$dir=$dir.$word[2];}
	return($dir);
    }
}
