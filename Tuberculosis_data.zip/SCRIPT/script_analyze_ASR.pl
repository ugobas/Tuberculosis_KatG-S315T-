#!/usr/bin/perl
#
# script_analyze_ASR.pl 
# Usage:
#  script_analyze_ASR.pl -tree <Newick file> -asr <ancestral seqs>
#  Options: -sons ! Print sons
#
# author Ugo Bastolla ubastolla@cbm.csic.es
# Centro de Biologia Molecular Severo Ochoa (CSIC-UAM), Madrid Spain
#
# It includes part of the program Ktreedist
# that calculates the minimum branch length distance (K tree score) between phylogenetic trees after fitting one scale parameter
# Copyright (C) 2007 Victor Soria-Carrasco & Jose Castresana
# Institute of Molecular Biology of Barcelona (IBMB), CSIC, Jordi Girona 18, 08034 Barcelona, Spain
# vscagr@ibmb.csic.es (VSC) & jcvagr@ibmb.csic.es (JC)
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
#
# Requirements:
#	Perl v.5.8.x or greater (previous version have not been tested)
#

use warnings;
use strict;

# Ktreedist	version 1.0
# Last modified 25 June 2007
my $version = "2.0";
my $monthyear = "November 2023";


# //////////////////////////////////////////////////////////////////////////////
# //////////////////////////////  HIDDEN OPTIONS  //////////////////////////////
# //////////////////////////////////////////////////////////////////////////////

# The variable hard_polytomies is "off" by default.
# By default, zero branch length partitions count in the calculation of the symmetric difference.
# With hard_polytomies "on", zero branch length partitions are collapsed and treated as polytomies for this calculation.
my $hard_polytomies = "off";

# Debug mode is "off" by default. With debug mode "on" you do not need to enter -rt and -ct for the reference tree and
# comparison tree/s files, respectively, but combinations of parameters to be entered may be less flexible.
my $debugmode = "off";

# Safe mode is "off" by default. With safe mode "on" you are warned in case of overwriting files. When safe mode is "on"
# a new visible option appears to control overwriting:
#          -f  Overwrite output files
my $safemode = "off";

# Number of decimal places for branch lenghts in scaled trees
my $precision = 10;

# //////////////////////////////////////////////////////////////////////////////
# ///////////////////////////////  PRELIMINARS  ////////////////////////////////
# //////////////////////////////////////////////////////////////////////////////

print "\n$0 version 1.0 -  Nov 2023\n",
    "For all nodes in the tree, it prints in the file .graph:\n",
    "2-parent 3-branch length 4-number of sons 5...-sons\n",
    "Based on Ktreedist by Castresana's group\n",
    "Mandatory arguments: -tree <Newick format> -asr <Anc. Seq.> \n\n";

# Get command line arguments
my $tree="";
my $seq="";
my $asr="";
my $print_sons=0;
for(my $i=0; $i<scalar(@ARGV); $i++){
    if($ARGV[$i] eq "-tree"){
	$i++; $tree=$ARGV[$i];
    }elsif($ARGV[$i] eq "-seq"){
	$i++; $seq=$ARGV[$i];
    }elsif($ARGV[$i] eq "-asr"){
	$i++; $asr=$ARGV[$i];
    }elsif($ARGV[$i] eq "-sons"){
	$print_sons=1;
    }else{
	print "WARNING, unknown option ",$ARGV[$i],"\n";
    }
}
if($tree eq "" || $seq eq "" || $asr eq ""){
    print "ERROR, options -tree -asr and -seq are mandatory\n";
    usage();
}
if(!-e $tree || !-e $seq || !-e $asr){
    print "ERROR, files $tree or $seq or $asr does not exist\n";
    die;
}


# DEFAULT DEFINITIONS, PATHS & FILENAMES
#-------------------------------------------------------------------------------
# Get paths & filenames
my ($filename_tree, $filename_tree_woext, $path_tree) = 
    get_path_filename($tree);
#This is really necessary in case of no full path
$tree = "$path_tree$filename_tree" if ($tree ne "");

# Do initial checkings and get trees if there are no errors
print "Checkings:\n";
my ($reftr, $nametr, $txbl, $root, $bl, $t0) = initial_check ($tree);
my $reftree = ($$reftr);
my %nametrees = (%$nametr);
my $taxblock = ($$txbl);
my $rooted = ($$root);
my $bk_line = ($$bl);
my $tree0 = ($$t0);

# //////////////////////////////////////////////////////////////////////////////
# ///////////////////////////////////  MAIN  ///////////////////////////////////
# //////////////////////////////////////////////////////////////////////////////


my ($claA, $claB, $nodnam, $brl, $sp, $rt) = get_partitions_tree($tree0, "yes");
my @clados0A = (@$claA);
my @clados0B = (@$claB);
my @clados0 = (@clados0A, @clados0B);
my %brlen0 = (%$brl);
my @species0 = (@$sp);
my @node_name = (@$nodnam);

my @nodes=get_nodes(\@clados0A, \%brlen0, $filename_tree, 0, 1, 1, $rooted, \@node_name);

my ($all_seq) = Read_ASR($seq, $asr, \@nodes);

Analyze_ASR($all_seq, $asr, \@nodes);


exit();

#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------
#-------------------------------- SUBROUTINES ----------------------------------
#-------------------------------------------------------------------------------
#-------------------------------------------------------------------------------

sub help{

    print "Program $0\n",
    "For each node of the tree prints the following columns:\n",
    "2-parent 3-branch_length 4-number-of-sons 5...-sons\n";
    print
	"USAGE: ",$0,"\n",
	" -tree <Newick file> (mandatory)\n\n";
}

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Get paths & filenames (with and without extension) ///
sub get_path_filename{
	my $filename = shift(@_);
	my $path = $filename;
	$filename =~ s/.+[\/|\\]//g;
	my $filename_woext = $filename;
	$filename_woext =~ s/\..+//g;
	$path =~ s/\/*$filename$//g;
	$path = "./".$path if ($path !~ m/^[A-Z]*\:*[\/|\.\/|\\]/);
	$path = $path."/" if ($path !~ m/[\/|\\]$/);

	return($filename, $filename_woext, $path);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-


#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Print usage howto ///
sub usage{
    my $wrong_option = shift(@_);
    print "WARNING: Option '$wrong_option' not recognized.\n\n" if (defined ($wrong_option));
    print "Usage:\n";
    print " $0 -tree <tree with named internal branches> -seq <ancestral sequences> [<options>]\n";
    print "    Options:\n";
    print "         -sons ! Print list of sons\n";
    print "         \n";
    exit();
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# This subroutine checks several parameters before starting tree comparison:
#	- if input and output files exist (and can be writen)
#	- kind of line break
#	- input files format (nexus needs internal conversion to newick)
#	- if all trees are rooted or unrooted
#	- if trees have branch length information
#	- if trees have same tip names
sub initial_check{
    my $reftree = shift(@_);
    my %nametrees = ();
    my $nexus = "";
    my $taxblock = "no";
    my $out = "no";

    my $rooted = "no";
    
    my $ERR = 0;
    my $ERROR = "";
    my $WARNING = "";
    
    # =====================================
    # Check existence of files
    # =====================================
    if ($reftree eq ""){usage();}
    elsif (!-e $reftree){
	$ERROR = "     File '$reftree' does not exist\n";
	die("ERROR:\n$ERROR\n");
    }
    
    # =====================================
    # =====================================
    
    # =====================================
    #Check line break
    # =====================================
    print "Line break...  ";
    my @lines_ref = break_line($reftree);
    my $breakline_ref = shift(@lines_ref);
    my $bk_line_line = "OK ($breakline_ref)";
    print "$bk_line_line\n";
    
    # =====================================
    # =====================================
    
    # =====================================
    # Check output files
    # =====================================

    # =====================================
    # =====================================
    
    # =====================================
    # CHECK if files are nexus or newick
    # =====================================
    print "File format...  ";
    
    my @lines = ([@lines_ref]);
    my $fileformat_line = "";
    my $formaterr = "";
    my @reftrees = ();
    if(scalar(@lines)>1){
	print "WARNING, ",scalar(@lines)," trees read, only the first one will be used\n";
    }

    for (my $l=0; $l < 1; $l++){ #scalar(@lines)
	my $newick = "yes";
	my @aux = @{$lines[$l]};
	
	# Check newick
	# -------------------------------------
	my $save = "";
	foreach my $a (@aux){
	    next if ($a =~ m/^[\n|\/|\#|\>]/);
	    $a =~ s/^\[.+\]//g if ($a =~ m/^\[.+\]/);
	    $save = $save.$a;
	    chomp($save);
	}
	my @trs = split (/;/, $save);
	foreach (@trs){
	    $_ = $_.";";
	    my @aux = split(/\,/, $_);
	    my $n_intercom = scalar(@aux);
	    @aux = split(/ *\: *[0-9]+\.*[0-9]*e*E*\-*[0-9]* *| *\, *| *\( *| *\) *[0-9]*\.*[0-9]* *| *\;/,
			 $_);
	    my $n_spp = 0;
	    foreach my $a (@aux){
		$n_spp++ if ($a ne "");
	    }
	    @aux = split (/\(/,$_);
	    my $o_par = scalar(@aux);
	    @aux = split (/\)/,$_);
	    my $c_par = scalar(@aux);


	    print "n_comas = $n_intercom n_sp= $n_spp o_par= $o_par c_par= $c_par\n";

	    if ((!/^\(/ && !/\;$/) || 
		(($n_intercom != $n_spp)&&(2*$n_intercom-1 != $n_spp) && (2*$n_intercom-2 != $n_spp)) || 
		($o_par != $c_par)){

		$newick = "no";
		last;
	    }
	}
	if ($newick eq "yes"){
	    if ($fileformat_line eq ""){
		$fileformat_line = "newick";
	    }else{
		$fileformat_line = $fileformat_line." & newick";
	    }
	    if ($l == 0){ @reftrees = @trs; }
	}
	
	if ($newick eq "no"){
	    # Check nexus
	    # -------------------------------------
	    my $nex = "no";
	    my $confirmnex = "no";
	    foreach (@aux){
		next if (/^[\n|\/|\>]|^[ |\t]+$/);
		if (/^[ |\t]*\#NEXUS/){
		    $nex = "yes";
		    next;
		}
		if ($nex eq "yes"){
		    if (/TREE/i){
			if ($fileformat_line eq ""){
			    $fileformat_line = "nexus";
			}
			else{
			    $fileformat_line = $fileformat_line." & nexus";
			}
			$confirmnex = "yes";
			last;
		    }
		}
		
	    }
	    if (($nex eq "no") || ($nex eq "yes" && $confirmnex eq "no")){
		$nexus = $nexus."no";
	    }else{
		my ($nametr, $txbl, $trs) = nexus2newick(\@aux);
		my %auxname = (%$nametr);
		$taxblock = ($$txbl);
		if ($l > 0){last;}
		@reftrees = (@$trs);
		$fileformat_line = $fileformat_line." with taxa block" if ($taxblock eq "yes");
		$nametrees{$reftree} = \%auxname;
		$nexus = $nexus."yes";
	    }
	}else{ 
	    $nexus = $nexus."no";
	}
	
	if (($newick eq "no") && ($nexus =~ m/no$/)){
	    if ($formaterr ne ""){
		$formaterr = $formaterr."\n          &\n          format of file "; 
	    }else{
		$formaterr = "Format of file "; 
	    }
	    if ($l == 0) {
		$formaterr = $formaterr." '$reftree' not recognized";
	    }
	}
    }
    if ($formaterr ne ""){
	print "\n";
	die ("     ERROR:\n          $formaterr.\n\n");
    }else{
	print "OK ($fileformat_line)\n";
    }
    # =====================================
    # =====================================
    
    # =====================================
    # Reading trees
    # =====================================
    my @rtrs = ();
    my @auxtrees = (@reftrees);
    
    for (my $t=0; $t < scalar(@auxtrees); $t++){
	my @trees = ();
	my $line = "";
	chomp($auxtrees[$t]);
	next if ($auxtrees[$t] =~ m/^[\n|\/|\#|\>]/);
	$auxtrees[$t] =~ s /^\[.+\]//g;
	if ($auxtrees[$t] =~ m/\;$/){
	    $line = $line.$auxtrees[$t];
	    if ($t < scalar (@reftrees)){ push (@rtrs, $line); }
	    $line = "";
	}else{
	    $line = $line.$auxtrees[$t];
	}
    }
    # =====================================
    # =====================================
    
    # =====================================
    # Check if there is more than one reference tree
    # =====================================
    print "Number of reference trees...  ";
    
    if (scalar(@rtrs) > 1){
	$WARNING = "\n     WARNING:  There is more than one tree in the reference file. Only the first one will be used.";
	print "$WARNING\n";
    }else{
	print "OK\n";
    }
    my $t0 = shift(@rtrs); #The first reference tree will be used
    
    # =====================================
    # =====================================
    
    # =====================================
    # Check branch lengths
    # =====================================
    print "Checking branch lengths...  ";
    my @trs = ($t0);
    my $nobrlen = "no";
    my $wrongbrlen = "no";	
    my $indexes = "";
    my $indexes_wrbrlen = "";
    my $n_wo_brlen = 0;
    my $n_wr_wo_brlen = 0;	
    my $refbr = "yes";
    my $wrrefbr = "yes";
    for (my $i=0; $i < scalar(@trs); $i++){
	if ($i == 0){ # It's reftree
	    if (!grep (/\:/, $trs[$i])){
		$refbr = "no";
		$nobrlen = "yes";
	    }
	}else{ # It's comptrees
	    last;
	}
	
	#Checks branch lengths are right (not negative)
	my @aux = split (/\:|\)|\,/, $trs[$i]);
	foreach my $a (@aux){
	    if ($a=~ m/^\-[0-9]+/){
		$wrongbrlen = "yes";
		if ($i == 0){					
		    $wrrefbr = "no";
		}else{
		    last;
		}
	    }
	}		
    }
    $indexes =~ s/, $//g;
    $indexes_wrbrlen =~ s/, $//g;
    
    if ($nobrlen eq "yes"){
	my $brlenerr = "";
	if ($refbr eq "no") {
	    $brlenerr = "          Tree '$reftree' has no branch lengths.\n";
	}
	$ERROR = $ERROR."\n     ERROR (branch lengths):\n$brlenerr\n";
	print "$ERROR";
	$ERR = 1;
    }else{
	
	$ERROR = "$ERROR\n\n" if ($ERROR ne "");
	my $brlenerr = "";	
	if ($wrongbrlen eq "yes"){
	    if ($wrrefbr eq "no"){
		$brlenerr = "          Branch lengths of tree '$reftree' are incorrect (negative values).\n";			
	    }
	    if ($nobrlen eq "yes"){
		$ERROR = $ERROR."\n\n$brlenerr\n";
	    }else{
		$ERROR = "\n     ERROR (branch lengths):\n$brlenerr\n";			
	    }
	    print "$ERROR";
	    $ERR = 1;			
	}else{
	    print "OK\n";
	}
    }	
    $ERROR = "";
    # =====================================
    # =====================================
    
    # =====================================
    # Check species - tips
    # =====================================
    print "Tips in trees...  ";
    my @species = ();
    foreach my $t (@trs){
	my @sps = ();
	my @auxsps = ();
	if (grep (/\:/, $t)){
	    @auxsps = split (/ *\: *\-*[0-9]+\.*[0-9]*e*E*-*[0-9]* *| *\, *| *\( *| *\) *[0-9]*\.*[0-9]* *| *\; */, $t);
	}else{
	    @auxsps = split (/ *\, *| *\( *| *\) *| *\; */, $t);
	}
	foreach my $s (@auxsps){
	    my $auxs = $s;
	    $auxs =~ s/\'|\"//g;
	    $auxs =~ s/ /_/g;
	    $t =~ s/$s/$auxs/g;
	    push (@sps, $auxs) if ($auxs ne "");
	}
	push (@species, [@sps]);
	$t =~ s/ //g;
    }
    $t0 = $trs[0]; # Update reference tree
        
    # =====================================
    # =====================================
    
    # =====================================
    # Check root
    # =====================================
    print "All trees rooted or all unrooted...  \n";
    my $n_rooted = 0;
    my $n_trees = 0;
    my @treenumber = ();
    foreach my $t (@trs){
	my $aux = $t;
	$aux =~ s/\)[0-9]+\:[0-9]+\.*[0-9]*/\)/g;# for bootstrap
	$aux =~ s/^\(|\)\;$|\:[0-9]+\.*[0-9]*//g;
	my @aux2 = split (/(\(|\))/,$aux);
	my $opened = 0;
	my $closed = 0;
	my $chg = "";
	foreach my $a (@aux2){
	    next if ($a eq "\n" || $a eq "");
	    $opened ++ if ($a eq "\(");
	    $closed ++ if ($a eq "\)");
	    if ($opened != 0){
		$a = "\\(" if ($a eq "\(");
		$a = "\\)" if ($a eq "\)");
		$chg = $chg.$a;
	    }
	    if (($opened == $closed) && ($opened != 0) && ($chg ne $a)){
		$aux =~ s/$chg/X/g;
		$chg = "";
		$opened = 0;
		$closed = 0;
	    }
	}
	my @cm = split (/\,/, $aux);
	if (scalar (@cm) == 2) {
	    push (@treenumber, $n_trees."R");
	    $n_rooted++;
	}else {
	    push (@treenumber, $n_trees."U");
	}
	$n_trees++;
    }
    print "$n_rooted rooted trees over $n_trees\n";
    

    my $errormsg = 
	"\n*********************************************\n".
	'  There were one or more ERRORS. See above.  '.
	"\n*********************************************\n\n";
    
    die ("$errormsg") if ($ERR == 1);

    return (\$reftree, \%nametrees, \$taxblock, \$rooted, \$bk_line, \$t0);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Check kind of line break (and change it to UNIX if necessary) ///
sub break_line{
    my $file = shift(@_);
    my $break = "";
    my $br = "\n";
    open (FILE, "$file") or die ("Cannot open file $file");
    my @file = (<FILE>);
    close(FILE);
    foreach (@file){
	if (/\r\n/){ $break = 'DOS'; $br = "\r\n"; last; }
	if (/\r/)  { $break = 'MAC'; $br = "\r"; last; }
	if (/\n/)  { $break = 'UNIX'; last; }
    }
    my @lines = ();
    if ($break ne 'UNIX'){
	my $all_lines = "";
	foreach (@file){
	    s/$br/\n/g;
	    $all_lines = $all_lines.$_;
	}
	@lines = split (/\n/, $all_lines);
    }
    else{
	@lines = @file;
    }
    return($break, @lines);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Converts nexus tree to newick ///
sub nexus2newick{
	my ($a, $b) = @_;
	my @aux = (@$a);
	my @newicktrees = ();
	my %nametrees = ();
	my $taxblock = "no";
	my $treeblock = "no";
	if (grep (/translate/i, @aux)){ # Nexus with taxa block
		$taxblock = "yes";
		my %taxa = ();
		my $n = 0;
		my $continue = "no";
		foreach (@aux){

			if (/^Begin +TREES/i){
				$treeblock = "yes";
			}
			next if ($treeblock eq "no");
			last if (/End\;/ && $treeblock eq "yes");

			$continue = "yes" if (/Translate/i);
			next if ($continue eq "no");
			
			if (/^( *|\t*)[0-9]+/){
				s/^( +|\t+)//g;
				my @aux2 = split(/^([0-9]+)/, $_);
				my $number = $aux2[1];
				my $taxon = $aux2[2];
				$taxon =~ s/\t+| +|\,|\;|\n//g;
				$taxa{"$number"} = $taxon;
			}
			
			if (/^ *\t*[U|R]*TREE/i){
				my $tree = $_;
				my $nametree = $tree;
				$nametree =~ s/^ *\t*[U|R]*TREE *\t*|\[\&r*u*\]| *\t*(\[.+\])* *\t*\=.*|\'|\n//ig;
				$tree =~ s/.+=[ |\t|\[|\]|\&|a-z]*\(/\(/ig;
				if (grep (/\:/,$tree)){
					my @auxtree = split (/([0-9]+\:)/, $tree);
					$tree = "";
					foreach my $a (@auxtree){
						if ($a =~ m/^[0-9]+\:/){
							$a =~ s/\://g;
							$a = $taxa{$a};
							$a = $a.":";
						}
						$tree = $tree.$a;
					}
				}
				else{# No branch lengths
					my @auxtree = split (/([0-9]+)/, $tree);
					$tree = "";
					foreach my $a (@auxtree){
						$a = $taxa{$a} if ($a =~ m/^[0-9]+/);
						$tree = $tree.$a;
					}
				}
				push (@newicktrees, $tree);
				$nametrees{$n} = $nametree;
				$n++;
			}
		}
	}
	else{ # Nexus without taxa block
		my $n = 0;
		foreach (@aux){
			if (/^Begin +TREES/i){
				$treeblock = "yes";
			}
			next if ($treeblock eq "no");
			last if (/End\;/ && $treeblock eq "yes");

			if (/^ *\t*[U|R]*TREE/i){
				my $tree = $_;
				my $nametree = $tree;
				$nametree =~ s/^ *\t*[U|R]*TREE *\t*|\[\&r*u*\]| *\t*(\[.+\])* *\t*\=.*|\'|\n//ig;
				$tree =~ s/.+=[ |\t|\[|\]|\&|a-z]*\(/\(/ig;
				push (@newicktrees, $tree);
				$nametrees{$n} = $nametree;
				$n++;
			}
		}
	}

	return (\%nametrees, \$taxblock, \@newicktrees);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Converts a newick file to nexus ///
sub newick2nexus{
	my ($sc, $txbl, $nt, $cpt) = @_;
	my $scaled = ($$sc);
	my $taxblock = ($$txbl);
	my %nametrees = (%$nt);
	my $comptrees = ($$cpt);
	open (FILE, "$scaled") or die ("Cannot open $scaled");
		my @auxfile = (<FILE>);
	close (FILE);
	open (FILE, ">$scaled") or die ("Cannot write to $scaled");
		print FILE "#NEXUS\n\n";
		print FILE "\[\!\n";
		print FILE "File generated by Ktreedist version $version\n\n";
		print FILE "Reference file: '$reftree'\n";
		print FILE "Comparison file: '$comptrees'\n";
		print FILE "]\n\n";
		print FILE "Begin TREES;\n\n";
		my $ntips = 1;
		my %nametips = ();
		if ($taxblock eq "yes"){
			print FILE "\tTranslate\n";
			my @aux = ();
			foreach my $af (@auxfile){
				if ($af =~ m/^\(/){
					@aux = split (/\,|\(|\)|\;/, $af);
					last;
				}
			}
			my $ind = 1;
			my $taxblock_output = "";
			foreach my $a (@aux){
				if ($a =~ m/^.+\:/){
					$a =~ s/\:.+//g;
					$taxblock_output = $taxblock_output."\t\t$ind\t'$a',\n";
					$nametips{$ind} = $a;
					$ind++;
				}
			}
			$ntips = $ind;
			$taxblock_output =~ s/,\n$/\n\t;\n\n/g;
			print FILE $taxblock_output;
		}
		for (my $i=0; $i < scalar(@auxfile); $i++){
			if ($auxfile[$i] =~ m/^\(/){
				if ($taxblock eq "yes"){
					for (my $j=1; $j < $ntips; $j++){
						$auxfile[$i] =~ s/$nametips{$j}/$j/g;
					}
				}
				print FILE "TREE '$nametrees{$comptrees}{$i}' = $auxfile[$i]";
			}
			else{
				print FILE $auxfile[$i];
			}
		}
		print FILE "\nEnd;\n";
	close (FILE);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# /// Get partitions ///
sub get_partitions_tree{

    my $tree = shift(@_);
    my $separated = shift(@_);
    $tree =~ s/\) *[0-9]*\.*[0-9]*/\)/g;
    my @aux = split(/(:|,|\)|\;|\()/, $tree);
    my @treesplit = ();
    foreach my $a (@aux){
	push (@treesplit, $a) if ($a ne "");
    }
    
    my %brlen = ();
    my %aux_brlen = ();
    my @cladosA = ();
    my @cladosB = ();
    my @species = ();
    my @opened = ();
    my $n_comas = 0;
    my $cont = -1;
    my $rooted = "no";
    my $num_node_name=0;
    my @node_name = ();

    print "Getting internal partitions\n";
    # Get internal partitions
    for (my $i=0; $i < scalar(@treesplit); $i++) {
	$n_comas ++ if (($treesplit[$i] eq "\,") && ($#opened == 0));
	if ($treesplit[$i] eq "\("){
	    $cont++;
	    push (@opened, $cont);
	}
	if ($treesplit[$i] eq "\:"){
	    if ($treesplit[$i-1] =~ m/\w+/){
		if ($treesplit[$i-2] ne "\)"){# it's a tip and not a bootstrap value
		    push (@species, $treesplit[$i-1]);
		    $aux_brlen{$species[$#species]} = $treesplit[$i+1]; # $# largest index
		    foreach my $o (@opened){
			push (@{$cladosA[$o]}, $treesplit[$i-1]);
		    }
		#}elsif($treesplit[$i-1] ne "\)"){
		 #   print $treesplit[$i-1]," "; $num_node_name++;
		}
	    }
	}
	if ($treesplit[$i] eq "\)"){
	    if ($treesplit[$i+1] ne ";"){
		my $br;
		if($num_node_name==0 && $treesplit[$i+2] ne ":"){
		    $brlen{$cladosA[$opened[$#opened]]} = $treesplit[$i+2];
		}else{
		    $brlen{$cladosA[$opened[$#opened]]} = $treesplit[$i+3];
		}
		if ($treesplit[$i+1] ne "\:"){
		    #print $treesplit[$i+1], " ";
		    #push(@node_name, $treesplit[$i+1]);
		    $node_name[$opened[$#opened]]=$treesplit[$i+1];
		    $num_node_name++;
		}
	    }
	    pop(@opened);
	}
    }
    $rooted = "yes" if ($n_comas == 1);
    print "\n$num_node_name names of internal nodes root $rooted\n";
    $num_node_name=scalar(@node_name);
    print "There are $num_node_name node names, ", scalar(@cladosA),
    " internal nodes and ",scalar(@species), " tip nodes\n";

    #shift(@cladosA); # First partition is all the tree
    #shift(@node_name);
    #print "There are ",scalar(@cladosA)," internal nodes\n";
    my $index = $#cladosA+1;
    
    #Get symmetric partitions
    for (my $i=0; $i < scalar(@cladosA); $i++){
	if(scalar(@{$cladosA[$i]}) == scalar(@species)){ #&& $rooted eq "no"
	    @{$cladosB[$i]} = ();
	    $brlen{$cladosA[$i]} = 0;
	}
	foreach my $sp (@species){
	    if (!grep(/^$sp$/, @{$cladosA[$i]})){
		push (@{$cladosB[$i]}, $sp);
	    }
	}
	push (@{$cladosB[$i]}, "root") if ($rooted eq "yes");
	$brlen{$cladosB[$i]} = $brlen{$cladosA[$i]};
    }
    # Get tip partitions
    foreach my $sp (@species){
	$cladosA[$index][0] = $sp;
	$brlen{$cladosA[$#cladosA]} = $aux_brlen{$sp};
	foreach my $sp2 (@species){
	    push (@{$cladosB[$index]}, $sp2) if ($sp2 ne $sp);
	}
	push (@{$cladosB[$index]}, "root") if ($rooted eq "yes");
	$brlen{$cladosB[$#cladosB]} = $aux_brlen{$sp};
	$index++;
    }
 
    print "Total number of nodes: ",scalar(@cladosA),"\n";
   
    my @clados = ();
    my %brlen_aux = ();
    
    # Join partitions when requested
    if ($separated eq "no"){
	for (my $i=0; $i < scalar (@cladosA); $i++){
	    push (@clados, [@{$cladosA[$i]}]);
	    $brlen_aux{$clados[$#clados]} = $brlen{$cladosA[$i]};
	    push (@clados, [@{$cladosB[$i]}]);
	    $brlen_aux{$clados[$#clados]} = $brlen{$cladosB[$i]};
	}
	%brlen = %brlen_aux;
	return (\@clados, \@node_name, \%brlen, \@species, $rooted);
    }
    else{
	return (\@cladosA, \@cladosB, \@node_name, \%brlen, \@species, $rooted);
    }
}

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-
# Change line break from UNIX to DOS or MAC
sub unix2macdos{
    my $kind = shift(@_);
    my $file = shift(@_);
    my $bl = "\n";
    if ($kind eq "MAC"){ $bl = "\r"; }
    elsif ($kind eq "DOS"){	$bl = "\r\n"; }
    open (FILE, "$file") or die ("Cannot open $file");
    my @aux=(<FILE>);
    close(FILE);
    open (FILE, ">$file") or die ("Cannot write to $file");
    foreach (@aux){
	s/\n/$bl/g;
	print FILE $_;
    }
    close(FILE);
}
#-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-:-

sub get_nodes{
    my  ($cl, $brl, $file, $ntree, $tot_trees, $write, $rooted, $nod) = @_;
    my @clados = (@$cl);
    my %brlen = (%$brl);
    my @node_name = (@$nod);
    my $n_nodes=scalar(@clados);
    my $names;
    if(scalar(@node_name)){
	$names=1; print "Node names are provided\n";
    }else{
	$names=0; print "Node names are not provided\n";
    }
    #print "file= $file tree $ntree out of $tot_trees write= $write\n";
    
    my @node = ();
    # structure of array node:
    # index 0 = n.species
    # index 1: name
    # index 2: parent
    # index 3: branch length
    # index 4: list of species
    # index 5: name of parent

    my $max=1; my $nsp=0;
    for (my $i=0; $i < $n_nodes; $i++){
	$node[$i][0]=scalar(@{$clados[$i]});
	if($node[$i][0]==1){$node[$i][1]=$clados[$i][0]; $nsp++;}
	elsif($node[$i][0]>$max){$max=$node[$i][0];}
	$node[$i][3]=$brlen{$clados[$i]};  
	$node[$i][4]=$clados[$i];
	$node[$i][5]="";
    }

    # Name internal nodes
    my $nint;
    if($rooted eq "yes"){$nint=0;}
    else{$nint=1;}
    if($names == 0){
	for(my $n=$max; $n>1; $n--){
	    for (my $i=0; $i < $n_nodes; $i++){
		if($node[$i][0]==$n){
		    $node[$i][1]="Node$nint";
		    $nint++;
		}
	    }
	}
    }else{
	for (my $i=0; $i < $n_nodes; $i++){
	    if($node[$i][0]!=1){
		$node[$i][1]=$node_name[$i];
		$nint++;
	    }
	}
    }
    if($rooted ne "yes"){$nint--;}
    
    # Look for parent
    my $npar=0; my $nroot=0;
    for (my $i=0; $i < $n_nodes; $i++){
	$node[$i][2]=-1; # parent
	my $min=$n_nodes;
	for(my $j=0; $j<$n_nodes; $j++){
	    if($node[$j][0]<=$node[$i][0]){next;}
	    my $n_equal = 0;
	    foreach my $cl0 (@{$clados[$i]}){
		if (grep (/^$cl0$/, @{$clados[$j]})){
		    $n_equal++;
		}
	    }
	    if($n_equal==$node[$i][0] && $node[$j][0]<$min){
		$node[$i][2]=$j; $min=$node[$j][0];
	    }
	} 
	if($node[$i][2] >=0){
	    $node[$i][5]=$node[$node[$i][2]][1]; $npar++;
	}else{
	    if($node[$i][5] eq ""){$node[$i][5]="Node0";}
	    $nroot++;
	}
    }

    my $err=0;
    my $out="# $nsp species, $nint internal nodes, $n_nodes total nodes rooted $rooted ";
    if($n_nodes==(2*$nsp-3)){$out=sprintf("%s Tree is unrooted", $out);}
    elsif($n_nodes==(2*$nsp-2)){$out=sprintf("%s Tree is rooted", $out);}
    else{
	$out=sprintf("%s\nI do not know if tree is rooted or unrooted\n",$out); 
	$err=1;
    }
    $out=sprintf("%s\n# %d parent nodes have been determined + %d with root\n",
		 $out, $npar, $nroot);
    if($err){
	print $out; print "Species: ";
	for (my $i=0; $i < $n_nodes; $i++){
	    if($node[$i][0]==1){print $node[$i][1], " ";}
	}
	print "\n";
	die;
    }
    
    if($write){
	my $nameout=Remove_ext($file);
	if($tot_trees>1){$nameout=sprintf("%s.%d", $nameout, $ntree+1);}
	$nameout=sprintf("%s.graph", $nameout);
	print "Printing tree in graph format in $nameout\n";
	open(my $fo, '>', $nameout);
	print $fo $out;
	my $b1=0; my $b2=0;
	for (my $i=0; $i < $n_nodes; $i++){
	    my $b=$node[$i][3]; $b1+=$b; $b2+=$b*$b;
	}
	$b1/=$n_nodes; $b2=($b2-$n_nodes*$b1*$b1);
	if($n_nodes>1){$b2=sqrt($b2/($n_nodes-1));}
	my $err=0;
	my $out=sprintf("# %d branches, mean: %.4g CoV: %.3g\n",
			$n_nodes, $b1, $b2/$b1);
	print $fo $out;
	print $fo "#node\tparent\tbranch\tsons\n";
	for (my $i=0; $i < $n_nodes; $i++){
	    if($node[$i][3] eq ":"){
		print "ERROR, node $i ",
		"$node[$i][1] $node[$i][5] $node[$i][3] $node[$i][0]\n";
		$err ++;
	    }
	    $out=sprintf("%s\t%s\t%.4g\t%d",
			 $node[$i][1],$node[$i][5],$node[$i][3],$node[$i][0]);
	    if($print_sons){
		for(my $j=0; $j<$node[$i][0]; $j++){
		    $out=$out."\t".$node[$i][4]->[$j];
		}
	    }
	    print $fo $out,"\n";
	}
	close($fo);
	#if($err){die;}
    }

    return(@node);
}

sub Remove_ext{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out=sprintf("%s.%s", $out, $word[$i]);
    }
    return($out);
}

sub Read_ASR{ 
    my ($seq, $asr, $nod) = @_;
    my @nodes = @$nod;
    my @seq = ();
    my $n_nodes=scalar(@nodes);
    print "Name of first stored node: $nodes[0][1]\n";
    my $all=0;
    my $error=0;
    for(my $f=1; $f<=2; $f++){
	my $file; if($f==1){$file=$seq;}
	else{$file=$asr;}
	#print "Reading file $file\n";
	open(my $fh, '<', $file);
	if($f==1){<$fh>;}
	my $n=0;
	while (my $row = <$fh>){
	    chomp $row;
	    my @word;
	    if($f==1){@word=split(/\s+/, $row);} # phylip file
	    else{@word=split(/\t/, $row);}  # asr file
	    my $name=$word[0]; my $i;
	    for($i=0; $i<$n_nodes; $i++){
		if($name eq $nodes[$i][1]){last;}
	    }
	    #print "name= $name i= $i\n";
	    if($i >= $n_nodes){
		print "ERROR, node $n ($name) not found among $n_nodes\n";
		$error++;
		#die;
	    }
	    $seq[$i]=$word[1];
	    $n++;
	}
	close $fh;
	print "$n sequences read in file $file\n";
	$all+=$n;
    }
    print "Total number of sequences: $all\n";
    if($error){print "There were errors, exiting\n"; die;}
    return(\@seq);
}

sub Analyze_ASR{
    my ($s, $file, $nod)  = @_;
    my @nodes = @$nod;
    my @seq = @$s;
    my @parent = ();
    my @diff_parent = ();
    my @diff_root = ();
    my @time_root = ();

    my $root=-1; my $nroot=0;
    my $n_nodes=scalar(@nodes);
    for(my $i=0; $i<$n_nodes; $i++){
	$parent[$i]=$nodes[$i][2];
	if($parent[$i]<0){
	    $root=$i; $nroot++;
	}
    }
    if($nroot != 1){
	print "ERROR, $nroot root nodes found\n"; die;
    }

    my $error=0;
    my $nrev=0; my $nmut=0; 
    my $outname=Remove_extension($file).".ancestral";
    open(my $fo, '>', $outname);
    print "Writing results in file $outname\n";
    print $fo
	"#1=node",
	"\t2=parent",
	"\t3=mut_from_root",
	"\t4=mut_from_parent",
	"\t5=reversions_from_parent",
	"\t6=t_from_root",
	"\t7=t_from_parent",
	#"\t8=rate_from_root",
	#"\t9=rate_from_parent",
	"\n";
    for(my $i=0; $i<$n_nodes; $i++){
	my $k=$parent[$i];
	if($k<0){
	    $diff_parent[$i]=0;
	    $diff_root[$i]=0;
	    $time_root[$i]=0;
	    next;
	}
	if(length($seq[$i]) != length($seq[$i])){
	    print "ERROR at $i, different lengths ",
	    length($seq[$i])," and ",length($seq[$k]),"\n";
	    $error++;
	}
	$diff_parent[$i]=seq_diff($seq[$i],$seq[$k]);
	$diff_root[$i]=seq_diff($seq[$i],$seq[$root]);
	my $rev=Reversions($seq[$i],$seq[$k],$seq[$root]);
	$nrev+=$rev;
	$nmut+=$diff_parent[$i];
	my $t=$nodes[$i][3];
	while($k >= 0){
	    $t+=$nodes[$k][3];
	    $k=$parent[$k];
	}
	$time_root[$i]=$t;
	my $par;
	if($parent[$i]>=0){$par=$nodes[$parent[$i]][1];}
	else{$par="root";}
	print $fo $nodes[$i][1],
	"\t",$par,"\t",
	#"\t",$nodes[$i][0],
	"\t",$diff_root[$i],
	"\t",$diff_parent[$i],
	"\t",$rev,
	"\t",sprintf("%.6f",$time_root[$i]),
	"\t",sprintf("%.6f",$nodes[$i][3]),
	#"\t",sprintf("%.0f",$diff_root[$i]/$time_root[$i]),
	#"\t",sprintf("%.0f",$diff_parent[$i]/$nodes[$i][3]),
	"\n";
    }
    my $nmut_true=$nmut-$nrev;
    print $fo "# Total number of changes $nmut ",
    "Mutations: $nmut_true Reversions: $nrev\n";
    close $fo;

    if($error){
	print "ERROR, different sequence lengths\n"; die;
    }
}

sub Remove_extension{
    my @word=split(/\./, $_[0]);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-1); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}


sub seq_diff{
    my ($seqi, $seqk) = @_;
    my $l=length($seqi);
    my $diff=0;
    for(my $j=0; $j<$l; $j++){
	if(substr($seqi, $j, 1) ne substr($seqk, $j, 1)){
	    $diff++;
	}
    }
    return($diff);
}

sub Reversions{
    my ($seqi, $seqp, $seqr) = @_; # p:parent r:root
    my $l=length($seqi);
    my $diff=0;
    for(my $j=0; $j<$l; $j++){
	if((substr($seqi, $j, 1) ne substr($seqp, $j, 1)) &&
	    substr($seqp, $j, 1) ne substr($seqr, $j, 1)){
	    $diff++;
	}
    }
    return($diff);
}
