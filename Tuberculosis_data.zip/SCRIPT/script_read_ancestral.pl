#!/usr/bin/env perl 
use strict;
use warnings;

# For every model and for five types of mutations
# (S315T, Resistant, No Synonym, Synonym and Intergenic)
# this script reads the ancestral tree and inferred ancestral states.
# INPUT:
# mut.aa.type.txt or mut.dna.type.txt list of mutations (set_asr)
# OUTPUT:
# .ancestralTree : ancestral tree where the species name indicates the number
# of ancestral mutations;
# .ancestral : text file in which for each node there is the parent node, 
# the distances from root and from parent and the number of
# mutations present at the node of the five types
# .mutations : text file with the list of the mutations at each node
#

my @models=("STMTREV+F+G4","JTT+F+G4", #+F +F
	    "GTR+G4","TVM+G4");
my @modname=("AA_STMTREV","AA_JTT",
	     "DNA_GTR","DNA_TVM");
my @dirs=("AA_JTT_FG_DNA2_GTR_G",
	  "AA_JTT_FG_DNA_GTR_G",
	  "AA_STMTREV_FG_DNA2_TVM_G",
	  "AA_STMTREV_FG_DNA_TVM_G",
	  "AAsyn_STMTREV_FG",
	  "DNA_TVM_G"
	  #"AA_nosyn_STMTREV_FG",
	  #"STMTREV_F_G4Amino",
	  #"JTT_F_G4Amino",	  
	  #"DNA_noAA_GTR",
	  #"TVM_G4DNA",
	  #"GTR_G4DNA"
    );

my @set_asr=("mut.aa.S315T.txt",
	     "mut.aa.resistant.txt",
	     "mut.aa.aanores.txt",
	     "mut.dna.secondary.txt",
	     "mut.dna.syn.txt",
	     "mut.dna.intergenic.txt");
# from set_size.txt, number of possible mutations for each site:
my @tot_mut=(1,64707,10496866,12639,1312115,443669);
my @name_asr=("S315T","res","aa","sec","syn","ig"); #S315
my @name_phy=("S315T","resistant","aanores","secondary","syn","intergenic");
my @aa_set=(1,1,1,0,0,0);
my @print_set_names=(1,1,1,1,0,0);
my @best_mod=(0,0,0,3,3,3); # for aa: STMTREV_AA, for DNA: GTR
#my @best_mod=(1,1,1,3,3,3); # for aa: JTT, for DNA: TVM
my $script_name="/data/ubastolla/TUBERCULOSIS/SOURCE/script_tree_names.pl";

my $file_Repr="Results_Repr_rates";
my $file_Subst="Results_Subst_rates";

my $i=0; my @muts=(); my @mut_name=(); my @nmut=();
foreach my $file (@set_asr){
    $nmut[$i]=Read_mutations(\@muts, $i, $file);
    my @word=split(/\./, $file);
    $mut_name[$i]=$word[2];
    $i++;
}
my $nset=$i;

#
# struct of node: 0=name 1=parent name 2=parent index
# 3=t_from_root dna 4=t_from_parent dna 
# 5=t_from_root aa 6=t_from_parent aa 
# 7=descendants
# For each type 8= mut_from_root 9=mut_from_parent ...
# 25 t_to_leaves dna 26 t_to_leaves_aa
#
# Struct of mutation: 0=mut_dna 1=gene 2=wt_aa 3=mut_res 4=mut_aa

my $kdir=0;
foreach my $dir (@dirs){
    $kdir++;
    chdir($dir);
    print "Going down to folder $dir\n";

    my @nodes=(); my @seqs=(); my @read=();
    for(my $i=0; $i<$nset; $i++){$read[$i]=0;}
    for(my $i=3; $i<(7+2*$nset); $i++){$nodes[0][$i]=0;}

    my $set=0; my $num=0; my $tree;
    for(my $i=0; $i<scalar(@set_asr); $i++){
	my $m=$best_mod[$i];
	my $name="$dir.br.$modname[$m]";
	my $a_i="${name}.".Remove_extension($set_asr[$i], 1);
	my $asr_tree=$a_i.".ancestralTree";
	my $asr_seqs=$a_i.".ancestralStates";
	my $asr_graph=$a_i.".ancestral";
	if($i==2){$tree=$asr_tree;}

	if(!-e $asr_graph){
	    print "ERROR, file $asr_graph does not exist\n"; die;
	}
	my $n=Read_nodes(\@nodes, $asr_graph, $i, $aa_set[$i]);
	if($num==0){
	    $num=$n;
	}elsif($num != $n){
	    print "ERROR, $n nodes found at set $i while $num at set 0\n";
	    die;
	}
	
	my $tip_seqs="../mut.";
	if($aa_set[$i]){$tip_seqs=$tip_seqs."aa";}
	else{$tip_seqs=$tip_seqs."dna";}
	$tip_seqs=$tip_seqs.".${name_phy[$i]}.phy";
	print "Reading $tip_seqs\n";
	Read_states(\@seqs, $tip_seqs, \@nodes, $n, $nmut[$i], $i, 1);
	Read_states(\@seqs, $asr_seqs, \@nodes, $n, $nmut[$i], $i, 0);
	$read[$i]=1;
       
    }

    my $name=$dir;
    my $out="${name}.names";
    Print_names(\@nodes, $num, $nset, $out);

# Modify species names in tree
    my $command="$script_name -tree $tree -names $out";
    print $command, "\n";
    `$command`;
    $tree="${tree}.new";
    my $newtree=Remove_extension($tree, 5).".ancestralTree";
    $command="cp $tree ../$newtree";
    print $command, "\n";
    `$command`;

    chdir("../");

    $out="${name}.ancestral";
    Print_nodes(\@nodes, $num, $nset, $out);

    $out="${name}_${modname[$best_mod[0]]}.mutations";
    Print_muts(\@nodes, $num, \@seqs, \@muts, \@nmut, $nset, $out, $kdir);

} # end dir

sub Read_mutations {
    my ($muts, $set, $file)=@_;
    open(my $fh, '<', $file) or die 'Could not open $file!\n';
    my $n=0;
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row, 0, 1) eq "#"){next;}
	my @word=split(/\t/, $row);
	#print "$n $word[1] $word[2] $word[3]$word[4]$word[5]\n";
	$muts->[$set][$n][0]=$word[1]; # mut_dna
	$muts->[$set][$n][1]=$word[2]; # gene
	$muts->[$set][$n][2]=$word[3]; # wt_aa or wt_dna
	$muts->[$set][$n][3]=$word[4]; # mut_res
	$muts->[$set][$n][4]=$word[5]; # mut_aa or mut_dna
	$n++;
    }
    close $fh;
    print "$n mutations read in $file\n";
    return($n);
}

sub Read_nodes{
    my ($nodes, $file, $set, $aa)=@_;
    open(my $fh, '<', $file) or die 'Could not open $file!\n';
    print "Reading nodes in file $file\n";
    my $n=1;
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row, 0, 1) eq "#"){next;}
	my @word=split(/\t/, $row);
	my @w=split(/\s+/, $word[0]);
	if(0){
	    print $row, "\n";
	    for(my $j=0; $j<scalar(@w); $j++){
		print $j," ",$w[$j],"\n";
	    }
	    print "word\n";
	    for(my $j=1; $j<scalar(@word); $j++){
		print $j," ",$word[$j],"\n";
	    }
	    die;
	}

	if($set && ($nodes->[$n][0] ne $w[0])){
	    print "ERROR, node $n is $nodes->[$n][0] in set 0".
		" but in set $set it is ${w[0]}\n"; die;
	}
	if($set && ($nodes->[$n][1] ne $word[1])){
	    print "ERROR, parent of node $n is $nodes->[$n][1] in set 0".
		 " but in set $set it is ${word[1]}\n"; die;
	}
	if($n==1){ # root
	    $nodes->[0][0]=$word[1]; # node name
	    $nodes->[0][1]="NULL";
	    $nodes->[0][2]=-1; # All others are 0
	    my $c=8+2*$set;
	    $nodes->[0][$c]=0; # nmut from root
	    $nodes->[0][$c+1]=0; # nmut from parent
	}
	$nodes->[$n][0]=$w[0]; # node name 
	$nodes->[$n][1]=$word[1]; # parent name
	$nodes->[$n][2]=Find_index($nodes, $n, $word[1]);
	if($aa==0){
	    $nodes->[$n][3]=$word[6]; # t from root, dna
 	    $nodes->[$n][4]=$word[7]; # t from parent, dna
	}else{
	    $nodes->[$n][5]=$word[6]; # t from root, aa
 	    $nodes->[$n][6]=$word[7]; # t from parent, aa
	}

	my $c=8+2*$set;
	$nodes->[$n][$c]=$word[3]; # nmut from root
	$nodes->[$n][$c+1]=$word[4]; # nmut from parent
	$n++;
    }
    close $fh;
    print "$n nodes read in $file\n";
    if($set==0 || $set==3){
	my $t_col; if($aa==0){$t_col=25;}else{$t_col=26;}
	Count_descendants($nodes, $n, 7, $aa, $t_col);
    }
    return($n);
}

sub Find_index{
    my ($nodes, $n, $name)=@_;
    for(my $i=0; $i<$n; $i++){
	if($nodes->[$i][0] eq $name){return($i);}
    }
    print "ERROR, node $name not found among $n\n"; die;
}

sub Count_descendants{
    my ($nodes, $n, $col, $aa, $t_col)=@_;
    for(my $i=0; $i<$n; $i++){
	$nodes->[$i][$col]=0;
	$nodes->[$i][$t_col]=0; # t_to_leaves
    }
    for(my $i=1; $i<$n; $i++){
	if(substr($nodes->[$i][0], 0, 4) ne "Node"){ # tip
	    $nodes->[$i][$col]=1;
	    my $t_root;
	    if($aa){$t_root=$nodes->[$i][5];}else{$t_root=$nodes->[$i][3];}
	    $nodes->[$i][$t_col]=$t_root;
	    my $k=$nodes->[$i][2];
	    while($k >= 0){
		$nodes->[$k][$col]++;
		$nodes->[$k][$t_col]+=$t_root;
		$k=$nodes->[$k][2];
	    }
	}
    }
    for(my $i=0; $i<$n; $i++){
	if($nodes->[$i][$col]>0){
	    $nodes->[$i][$t_col]/=$nodes->[$i][$col];
	}
    }
}
	
sub Print_nodes{
    my ($nodes, $n, $nset, $file)=@_;
    open(my $fo, '>', $file);
    print $fo "1=name\t2=parent".
	"\t3=t_from_root_dna\t4=t_from_parent_dna".
	"\t5=t_from_root_aa\t6=t_from_parent_aa".
	"\t7=descendants";
    my $k=8; my $k1=9;
    for(my $j=0; $j<$nset; $j++){
	print $fo
	    "\t${k}=nmut_${name_asr[$j]}_from_root".
	    "\t${k1}=nmut_${name_asr[$j]}_from_parent";
	$k+=2; $k1+=2;
    }
    print $fo "\n";

    for(my $i=0; $i<$n; $i++){
	my $out=$nodes->[$i][0]."\t".$nodes->[$i][1]; # name, parent
	$out=$out.sprintf("\t%.5f", $nodes->[$i][3]); # t_from_root_dna
	$out=$out.sprintf("\t%.5f", $nodes->[$i][4]); # t_from_par_dna
	$out=$out.sprintf("\t%.5f", $nodes->[$i][5]); # t_from_root_aa
	$out=$out.sprintf("\t%.5f", $nodes->[$i][6]); # t_from_par_aa
	$out=$out.sprintf("\t%d", $nodes->[$i][7]);   # descendants
	my $k=8;
	for(my $j=0; $j<$nset; $j++){
	    $out=$out.sprintf("\t%d", $nodes->[$i][$k]);  # mut from root
	    $out=$out.sprintf("\t%d", $nodes->[$i][$k+1]);# mut from par
	    $k+=2;
	}
	print $fo $out,"\n";
    }
    close $fo;
    print "Writing $n nodes in $file\n";
}

sub Print_names{
    my ($nodes, $n, $nset, $file)=@_;
    open(my $fo, '>', $file);
    for(my $i=0; $i<$n; $i++){
	my $out=$nodes->[$i][0]." ";
	my $k=8;
	if($print_set_names[0]){
	    if($nodes->[$i][$k]){$out=$out."_T";}
	    else{$out=$out."_S";}
	}
	for(my $j=1; $j<$nset; $j++){
	    if($print_set_names[$j]==0){next;}
	    $k=8+2*$j;
	    $out=$out."_${name_asr[$j]}$nodes->[$i][$k]";  # mut from root
	}
	print $fo $out,"\n";
    }
    close $fo;
    print "Writing $n names in $file\n";
}

sub Read_states{
    my ($seqs, $file, $nodes, $num, $nmut, $set, $format)=@_;
    open(my $fh, '<', $file) or die 'Could not open $file !\n';
    print "Reading sequence of type ${mut_name[$set]} in $file\n";
    my $n=0; my ($ns, $nl)=(0,0);
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row, 0, 1) eq "#"){next;}
	my @word;
	if($format==1){
	    @word=split(/\s+/, $row);
	    if($ns==0){$ns=$word[0]; $nl=$word[1]; next;}
	}else{
	    @word=split(/\t/, $row);
	}

	#if($n<20){print "$n $word[0]\n$n $word[1]\n";}else{die;}
	my $k=Find_index($nodes, $num, $word[0]);
	$seqs->[$set][$k]=$word[1];
	if(length($word[1]) != $nmut){
	    print "ERROR, $nmut mutations expected in ${set_asr[$set]} ",
	    "but ", length($word[1])," found in sequence $n\n";
	    die;
	}
	$n++;
    }
    close $fh;
    print "$n sequences of set ${name_asr[$set]} read in $file\n";
    if($ns && ($ns != $n || $nl != $nmut)){
	print "ERROR, expected $ns species and $nl lines, found $n and $nmut\n";
	die;
    }
}

sub Print_muts{
    my ($nodes, $n, $seqs, $muts, $nmut, $nset, $file, $kdir)=@_;

    open(my $fo, '>', $file);
    print $fo "1=name\t2=parent".
	"\t3=t_from_root_dna\t4=t_from_root_aa".
	"\t5=descendants".
	"\t6=repr_rate_t_dna\t7=repr_rate_t_aa";
    print $fo "\n";

    my $mut_sec="IG_Rv3845_C_sodA_N";
    my $jsec=3; # set: secondary resistance
    my ($fo1, $fo2);
    # 0:S315T,no_sec 1:S315T,sec 2:T315S,no_sec 3:T315S,sec 
    my @rate1=(0,0,0,0); my @rate2=(0,0,0,0); my @nn=(0,0,0,0);
    my ($t_S, $t_T) = (0,0);
    my ($n_ST, $n_TS) = (0,0);

    open($fo1, '>', $file_Repr."_${kdir}.dat");
    open($fo2, '>', $file_Subst."_${kdir}.dat");
    print $fo1 "# Type_of_mutation\t$mut_sec\trepr_rate\n";

    my $tree=Remove_extension($file, 1);
    print $fo1 "#\n# tree: $tree\n";
    print $fo2 "#\n# tree: $tree\n";

    my @lmut=(); my @sum_mut=();
    for(my $j=0; $j<$nset; $j++){
	$sum_mut[$j]=0;
	$lmut[$j]=length($seqs->[$j][0]);
	if($lmut[$j] != $nmut->[$j]){
	    print "ERROR in set $j, read $nmut->[$j] mutations ",
	    "but $lmut[$j] ancestral characters\n";
	    die;
	}
	print "$lmut[$j] mutations of type $name_asr[$j]\n";
    }

    for(my $i=0; $i<$n; $i++){
	my $tip=0; if(substr($nodes->[$i][0],0,4) ne "Node"){$tip=1;}
	# if($tip){next;} # exclude leaves
	my $parent=$nodes->[$i][2];

	my $out=$nodes->[$i][0]."\t".$nodes->[$i][1]; # name parent
	$out=$out.sprintf("\t%.5f", $nodes->[$i][3]); # t_from_root_dna
	#$out=$out.sprintf("\t%.5f", $nodes->[$i][4]); # t_from parent dna
	$out=$out.sprintf("\t%.5f", $nodes->[$i][5]); # t_from_root_aa
	#$out=$out.sprintf("\t%.5f", $nodes->[$i][6]); # t_from parent aa
	$out=$out.sprintf("\t%d", $nodes->[$i][7]);   # descendants
	my $rate_aa=0; my $rate_dna=0;
	if($nodes->[$i][7]>0 && $nodes->[$i][25] > $nodes->[$i][3]){
	    my $rate=log($nodes->[$i][7]);
	    $rate_dna=$rate/(1-$nodes->[$i][3]/$nodes->[$i][25]);
	    $rate_aa= $rate/(1-$nodes->[$i][5]/$nodes->[$i][26]);
	}
	$out=$out.sprintf("\t%.4g", $rate_dna);
	$out=$out.sprintf("\t%.4g", $rate_aa);

	print $fo "###\n",$out, "\n";
	for(my $j=0; $j<$nset; $j++){
	    my $k=8+2*$j;
	    $out="# ".$name_asr[$j]."\tnmut_from_root:\t".$nodes->[$i][$k];
	    if($j==0 && $i){ # S315T, no root
		my $nmut_parent= $nodes->[$parent][$k];
		if($nmut_parent){$t_T += $nodes->[$i][6];}
		else{$t_S += $nodes->[$i][6];}
		if($nodes->[$i][$k] != $nmut_parent){ # new mut or reversion
		    my $is_sec=0;
		    for(my $l=0; $l<$lmut[$jsec]; $l++){
			if(substr($seqs->[$jsec][$i],$l, 1) ne 
			   substr($seqs->[$jsec][0], $l, 1) &&
			   $muts->[$jsec][$l][1] eq $mut_sec){
			    $is_sec=1; last;
			}
		    }
		    my $ff;
		    if($nodes->[$i][$k]){ # S315T
			$out=$out."\tNew S315T";
			$ff="S315T";
			$n_ST ++;
			if($tip==0){
			    my $type=$is_sec;
			    $nn[$type]++;
			    $rate1[$type]+=$rate_aa;
			    $rate2[$type]+=$rate_aa*$rate_aa;
			}
		    }else{ # T315S
			$out=$out."\tRever T315S";
			$ff="T315S";
			$n_TS ++; 
			if($tip==0){
			    my $type=2+$is_sec;
			    $nn[$type]++;
			    $rate1[$type]+=$rate_aa;
			    $rate2[$type]+=$rate_aa*$rate_aa;
			}
		    }
		    $out=$out.sprintf(" $is_sec $mut_sec repr_rate= %.4g",
				      $rate_aa);
		    print $fo1 "#$ff $is_sec",sprintf("\t%.4g\n",$rate_aa);
		}
	    } # end New S315T or Reversion 
	    print $fo $out, "\n";
	    for(my $l=0; $l<$lmut[$j]; $l++){
		if(substr($seqs->[$j][$i],$l, 1) ne
		   substr($seqs->[$j][$parent], $l, 1)){
		    $sum_mut[$j]++;
		}
	    }
	    if($tip){next;} # exclude leaves
	    for(my $l=0; $l<$lmut[$j]; $l++){
		if(substr($seqs->[$j][$i],$l, 1) eq 
		   substr($seqs->[$j][0], $l, 1)){
		    next; # Same a.a. or nuc as in root
		}
		$out=$muts->[$j][$l][1]."\t".
		    $muts->[$j][$l][2].
		    $muts->[$j][$l][3].
		    $muts->[$j][$l][4];
		print $fo $out, "\n";
	    }
	}
    }

    my $s2_S315=0; my $s2_T315=0;
    print $fo1 "# 1=$mut_sec 2=mean_repr_rate 3=sem n=$nn[0] $nn[1] (no tip)\n";
    for(my $i=0; $i<4; $i++){ # T315S-nosec, T315S-sec, S315T-nosec, S315T-sec
	if($nn[$i]){$rate1[$i]/=$nn[$i];}
	if($nn[$i]>1){
	    $rate2[$i]=($rate2[$i]/$nn[$i]-$rate1[$i]*$rate1[$i])/($nn[$i]-1);
	    $rate2[$i]=sqrt($rate2[$i]);
	}else{
	    $rate2[$i]=$rate1[$i];
	}
	if($i<2){$s2_S315+=$rate2[$i]*$rate2[$i];}
	if($i==0 || $i==3){$s2_T315+=$rate2[$i]*$rate2[$i];}
	print $fo1 sprintf("$i %.4g %.4g\n",
			   $rate1[$i], $rate2[$i]);
    }
    print $fo1 "# $tree t(diff_repr_rate_T315(sec-nosec))= ",
    sprintf("%.4g\n&\n",($rate1[1]-$rate1[0])/sqrt($s2_S315));
    print $fo1 "# $tree t(diff_repr_rate_T315-sec-S315-nosec))= ",
    sprintf("%.4g\n&\n",($rate1[3]-$rate1[0])/sqrt($s2_T315));
#
    print $fo2 "# tree $tree 1=mutation_rate 2=set\n"; 
    print $fo2 sprintf("1\t%.4g\tS315T\n", $n_ST/$t_S);
    print $fo2 sprintf("2\t%.4g\tT315S\n", $n_TS/$t_T);
    my $t_all=$t_S+$t_T;
    for(my $j=0; $j<$nset; $j++){
	if($j==0){print $fo2 "#";}
	print $fo2 sprintf("%d\t%.4g\t$name_asr[$j]\n",
			   2+$j,$sum_mut[$j]/($tot_mut[$j]*$t_all));
    }
    print $fo2 "&\n";

    close $fo;
    print "Writing $nset types of mutations at internal nodes in $file\n";
    close $fo1;
    print "Writing mutation rates in $file_Subst\n";
    close $fo2;
    print "Writing reproductive rates in $file_Repr\n";

}

sub Remove_extension{
    my ($name, $l)=@_;
    my @word=split(/\./, $name);
    my $out=$word[0];
    for(my $i=1; $i<(scalar(@word)-$l); $i++){
	$out="${out}.$word[$i]";
    }
    return $out;
}
