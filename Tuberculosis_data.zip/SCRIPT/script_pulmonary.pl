#!/usr/bin/env perl 
use strict;
use warnings;

my $pulmonary="PULM_EXTRAPULM.txt";
my $S315T="mut.aa.S315T.phy";
my $secondary="mut.dna.secondary.phy";

my @mut_S315T; my $n_S315T=1; # katG_S315T
$mut_S315T[0][0]=0; $mut_S315T[0][1]='S'; $mut_S315T[0][2]='T';
# IG_Rv3845_C_sodA_N 
my @mut_sec; my $n_sec=2;
$mut_sec[0][0]=5; $mut_sec[0][1]='G'; $mut_sec[0][2]='C'; # G719C
$mut_sec[1][0]=6; $mut_sec[1][1]='A'; $mut_sec[1][2]='G'; # A654G

my @samples; my $n=0; my $col=2; 
$n=Read_muts(\@samples, $n, $S315T, \@mut_S315T, \$col, 1);
$n=Read_muts(\@samples, $n, $secondary, \@mut_sec, \$col, 2);
Read_pulmonary($pulmonary, \@samples, $n);

# struct of sample: 0=name 1=pulmonary 2=katG_315 S/T 3=secondary etc.
# struct of muts: 0=pos in .phy 1=AA_WT 2= AA_mut 3=col of sample
my @nn=(0,0,0,0); my @npulm=(0,0,0,0);
for(my $i=0; $i<$n; $i++){
    my $a=$samples[$i][1];
    if($a!=0 && $a != 1 && $a!=-1){print "WARNING pulm= $a\n"; next;}
    my $b;
    if($samples[$i][2] eq "S"){$b=0;}
    elsif($samples[$i][2] eq "T"){$b=1;}
    else{print "WARNING $i AA315= $samples[$i][2]\n"; next;}
    $nn[$b]++; if($a){$npulm[$b]++;}
    my $c=-1;
    if($b==1){ # T315, but no secondary mutation
	if($samples[$i][3] ne "C" && $samples[$i][4] ne "G"){$c=2;}
	else{$c=3;}
    }
    if($c>=2){$nn[$c]++; if($a){$npulm[$c]++;}}
}
my $nameout="Results_pulm.txt";
open(my $fo, '>', $nameout);
print "Writing $nameout\n";
print $fo "files $pulmonary and $S315T\n";
print $fo "$n samples (S=$nn[0] T=$nn[1] T_nosec=$nn[2] T_sec=$nn[3])\n";
print $fo "npulm= $npulm[0] $npulm[1]  $npulm[2] $npulm[3]\n";
for($a=0; $a<4; $a++){
    my $p=$npulm[$a]/$nn[$a];
    print $fo "Conditional prob P(pulmonary|";
    if($a==0){print $fo "S315";}
    elsif($a==1){print $fo "T315";}
    elsif($a==2){print $fo "T315,no IG_Rv3845_C_sodA_N";}
    elsif($a==3){print $fo "T315,IG_Rv3845_C_sodA_N";}
    print $fo sprintf(")= %.4g err: %.4g n=%d\n",
		      $p, sqrt($p*(1-$p)/$nn[$a]), $nn[$a]);
}
close $fo;


sub Read_pulmonary{
    my ($file, $sample, $ns)=@_;
    for(my $j=0; $j<$ns; $j++){$sample->[$j][1]=-1;}
    open(my $fh, '<', $file) or die 'Could not open $file!\n';
    my ($n)= (0);
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row, 0, 1) eq "#"){next;}
	my @word=split(/\t/, $row);
	my $name=substr($word[0], 1, length($word[0])-1);
	my $k=-1;
	for(my $j=0; $j<$ns; $j++){
	    if($name eq $sample->[$j][0]){$k=$j; last;}
	}
	if($k<0){
	    print "ERROR, sequence $name not found in $S315T\n"; die;
	}
	if(substr($word[1],0,9) eq "Pulmonary"){$sample->[$k][1]=1;}
	else{$sample->[$k][1]=0;}
	$n++;
    }
    close $fh;
    if($n != $ns){
	print "WARNING, I expected $ns samples but found $n\n";
    }
}

sub Read_muts {
    my ($sample, $n_old, $file, $muts, $inicol, $ncol)=@_;
    open(my $fh, '<', $file) or die 'Could not open $file!\n';
    my $ini=$$inicol; my $end=$ini+$ncol-1;
    print "Writing columns from $ini to $end\n";
    my ($n, $ns, $nl, $l)= (0,0,0,0);
    while (my $row = <$fh>){
	chomp $row;
	if(substr($row, 0, 1) eq "#"){next;}
	my @word=split(/\s+/, $row);
	if($ns==0){$ns=$word[0]; $nl=$word[1]; next;} # read nseq
	if($l==0){$l=length($word[1]);}
	my $k;
	if($n_old==0){
	    $k=$n; $sample->[$k][0]=$word[0]; $n++;
	}else{
	    for($k=0; $k<$n_old; $k++){
		if($sample->[$k][0] eq $word[0]){last;}
	    }
	    if($k==$n_old){
		print "ERROR, $word[0] not found in previous list\n"; die;
	    }
	}
	my $col=$ini;
	for(my $c=0; $c<$ncol; $c++){
	    $sample->[$k][$col]=substr($word[1], $muts->[$c][0], 1);
	    $muts->[$c][3]=$col;
	    $col++;
	}
    }
    close $fh;
    if($n_old){$n=$n_old;}
    if($ns != $n || $nl != $l){
	print "ERROR, expected n=$ns l=$nl but found $n and $l\n"; die;
    }
    $$inicol=$ini+$ncol;
    return($n);
}
