#!/usr/bin/env perl 
use strict;
use warnings;

# type: 0=DNA only 1=AA_DNA 2=AA only
# 0: DNA.DNA 1: DNA.AA_DNA 2=DNA.AA 3=AA_DNA.AA_DNA 4=AA_DNA.AA 5=AA.AA 
my @name=("DNA.DNA",
	  "DNA.AA_DNA",
	  "DNA.AA",
	  "AA_DNA.AA_DNA",
	  "AA_DNA.AA",
	  "AA.AA"); 
my @name_score=("K1","K2","RF","lbr");

my @out_name; my @num;
my $nscore=scalar(@name_score); # K1 K2 RF len
my (@score_1, @score_2, @score_min, @score_max);

for(my $k=0; $k<scalar(@name); $k++){
    $out_name[$k]="Scores_diff.".$name[$k].".txt";
    print "Writing $out_name[$k]\n";
    open(my $fo, '>', $out_name[$k]);
    print $fo "# K1 K2 RF len SC12 SC21 SC22 pair\n";
    close $fo;
    $num[$k]=0;
    for(my $i=0; $i<$nscore; $i++){
	$score_1[$k][$i]=0;
	$score_2[$k][$i]=0;
	$score_min[$k][$i]=-1;
	$score_max[$k][$i]=-1;
    }
}

foreach my $file(`ls -1 Diff.*`){
    chomp $file;

    my @word=split(/\./, $file);
    my $type0=Get_type($word[1]);
    my $type1=Get_type($word[2]);
    my $p;
    if($type0==0){
	$p=$type1; # 0i
    }elsif($type0==1){
	if($type1==0){$p=1;} #10
	elsif($type1==1){$p=3;} # 11
	elsif($type1==2){$p=4;} # 12
    }elsif($type0==2){
	if($type1==0){$p=2;} # 20
	elsif($type1==1){$p=4;} # 21
	elsif($type1==2){$p=5;} # 22
    }
    print "$file is $type0 $type1 -> $p\n";

    open(my $fo, ">>", $out_name[$p]);
    open(my $fh, '<', $file) or die "Could not open $file\n";

    my ($K1, $K2, $RF, $Sc11, $Sc21, $Sc22, $lbr)=(0,0,0,0,0,0,0);
    my $l=0;
    while(my $row = <$fh>){
	if(substr($row, 0, 1) eq "#"){next;}
	$l++; if($l==1){next;}
	my @w=split(/\t/, $row);
	$K1=$w[2];
	$Sc11=$w[3];
	$K2=$w[4];
	$Sc21=$w[5];
	$Sc22=$w[6];
	$RF=$w[7];
	$lbr=$w[10];
	print $fo sprintf("%.4g\t%.4g\t%.4g\t%.4g\t%.4g\t%.4g\t%.4g",
			  $K1, $K2, $RF, $lbr, $Sc11, $Sc21, $Sc22);
	print $fo "\t${word[1]}.${word[2]}\n";
	# statistics
	$num[$p]++;
	for(my $i=0; $i<$nscore; $i++){
	    my $S;
	    if($i==0){$S=$K1;}
	    elsif($i==1){$S=$K2;}
	    elsif($i==2){$S=$RF;}
	    elsif($i==3){$S=$lbr;}
	    $score_1[$p][$i]+=$S; 
	    $score_2[$p][$i]+=$S*$S; 
	    if($score_min[$p][$i]<0 || $S<$score_min[$p][$i]){
		$score_min[$p][$i]=$S;
	    }
	    if($score_max[$p][$i]<0 || $S>$score_max[$p][$i]){
		$score_max[$p][$i]=$S;
	    }
	}
	last;
    }
    close $fh;
    close $fo;
}

for(my $p=0; $p<scalar(@name); $p++){
    print "Writing $out_name[$p]\n";
    open(my $fo, '>>', $out_name[$p]);
    for(my $i=0; $i<$nscore; $i++){
	$score_1[$p][$i]/=$num[$p];
	$score_2[$p][$i]=$score_2[$p][$i]-
	    $num[$p]*$score_1[$p][$i]*$score_1[$p][$i];
	print $fo "# $name_score[$i]",
	sprintf(" ave= %.4g", $score_1[$p][$i]),
	sprintf(" s.d.= %.4g", sqrt($score_2[$p][$i]/($num[$p]-1))),
	sprintf(" min= %.4g", $score_min[$p][$i]),	
	sprintf(" max= %.4g", $score_max[$p][$i]),"\n";
    }
}

sub Get_type{
    my $name=$_[0];
    if(substr($name, 0, 3) eq "DNA"){return(0);}
    my @word=split(/_/, $name);
    foreach my $w (@word){
	if(substr($w, 0, 3) eq "DNA"){return(1);}
    }
    return(2);
}
